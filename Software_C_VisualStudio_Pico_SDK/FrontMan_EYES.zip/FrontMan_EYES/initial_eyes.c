#include "initial_eyes.h"
#include "eye_colors.h"    // for your color_schemes[] if needed
#include <stdlib.h>
#include <math.h>
#include <stdbool.h>
#include "gc9a01.h"
#include "pico/time.h"

// Bring in your color globals from FrontMan.c
extern uint16_t COLOR_SCLERA;
extern uint16_t COLOR_PUPIL;

// Blink flags (from original)
static bool in_blink = false;
static bool blink_on = false;

// Stare timing constants (exactly as in FrontMan.c)
#define STARE_PERIOD_MS_MIN   5000
#define STARE_PERIOD_MS_MAX   20000
#define STARE_DURATION_MS     9000
#define STARE_CONTRACT_START  3000
#define STARE_CONTRACT_END    4000
#define STARE_HOLD_END        7000
#define STARE_RELAX_END       8000
#define STARE_COOLDOWN_MS     1000

// Geometry (from FrontMan.c)
#define SCREEN_WIDTH   240
#define SCREEN_HEIGHT  240
#define RECT_W         240
#define RECT_H         40
#define COLOR_BG       COLOR_BLACK
#define PUPIL_W        40
#define PUPIL_H        RECT_H
#define MIN_Y          ((int)(0.25 * (SCREEN_HEIGHT - RECT_H)))
#define MAX_Y          ((int)(0.77 * (SCREEN_HEIGHT - RECT_H)))
#define MIN_X          ((int)(0.25 * (SCREEN_WIDTH - PUPIL_W)))
#define MAX_X          ((int)(0.75 * (SCREEN_WIDTH - PUPIL_W)))

typedef enum { EYE_FIXATE, EYE_SACCADE, EYE_SMOOTH } EyePhase;
typedef enum { STARE_CONTRACT, STARE_EXPAND } StareType;
typedef enum { MODE_NORMAL, MODE_STARE, MODE_COOLDOWN } MainMode;

typedef struct {
    int rect_y, rect_y_old;
    int pupil_x, pupil_x_old;
    int rect_y_target, pupil_x_target;
    float rect_y_f, pupil_x_f;
    float rect_y_step, pupil_x_step;
    int smooth_steps, smooth_step_count;
    EyePhase phase;
    absolute_time_t until;
} EyeState;

// Module‐local display handles
static DisplayPins* d1;
static DisplayPins* d2;

// Eye state
static EyeState eye_state;
static float last_sclera_scale = 1.0f, last_pupil_scale = 1.0f;
static StareType stare_type = STARE_CONTRACT;
static MainMode current_mode = MODE_NORMAL;

static absolute_time_t stare_trigger_time, stare_end_time;
static absolute_time_t cooldown_end_time;
static absolute_time_t blink_end_time, next_blink_time;
static absolute_time_t next_eye_frame, next_smooth_step_time;

//------------------------------------------------------------------------------
// Helpers
//------------------------------------------------------------------------------
static inline bool time_passed(absolute_time_t now, absolute_time_t deadline) {
    return to_us_since_boot(now) >= to_us_since_boot(deadline);
}

static int random_stare_period(void) {
    return STARE_PERIOD_MS_MIN
         + rand() % (STARE_PERIOD_MS_MAX - STARE_PERIOD_MS_MIN + 1);
}

//------------------------------------------------------------------------------
// Exactly as in FrontMan.c:
// Clear the previous 240×40 “band” where the eye was drawn
//------------------------------------------------------------------------------
static void clear_old_eye(EyeState *s) {
    gc9a01_fast_fill_rect(d1,
                          0,
                          s->rect_y_old,
                          RECT_W,
                          RECT_H,
                          COLOR_BG);
    gc9a01_fast_fill_rect(d2,
                          0,
                          s->rect_y_old,
                          RECT_W,
                          RECT_H,
                          COLOR_BG);
}

//------------------------------------------------------------------------------
// Draw the eye with minimal clearing to avoid flicker.
//------------------------------------------------------------------------------  
static void draw_eye(EyeState *s) {
    int old_y = s->rect_y_old;
    int new_y = s->rect_y;

    // 1) Clear only the non‐overlapping part of the old band
    if (new_y > old_y) {
        // eye moved down: clear top strip of old band
        int overlap = (old_y + RECT_H) - new_y;
        if (overlap < 0) overlap = 0;
        if (overlap > RECT_H) overlap = RECT_H;
        int clear_h = RECT_H - overlap;
        if (clear_h > 0) {
            gc9a01_fast_fill_rect(d1, 0, old_y,     RECT_W, clear_h, COLOR_BG);
            gc9a01_fast_fill_rect(d2, 0, old_y,     RECT_W, clear_h, COLOR_BG);
        }
    } else if (new_y < old_y) {
        // eye moved up: clear bottom strip of old band
        int overlap = (new_y + RECT_H) - old_y;
        if (overlap < 0) overlap = 0;
        if (overlap > RECT_H) overlap = RECT_H;
        int clear_h = RECT_H - overlap;
        if (clear_h > 0) {
            int clear_y = old_y + overlap;
            gc9a01_fast_fill_rect(d1, 0, clear_y,   RECT_W, clear_h, COLOR_BG);
            gc9a01_fast_fill_rect(d2, 0, clear_y,   RECT_W, clear_h, COLOR_BG);
        }
    }
    // if new_y == old_y, no clear needed

    // 2) Draw the new sclera band
    gc9a01_fast_fill_rect(d1,
                          0,
                          new_y,
                          RECT_W,
                          RECT_H,
                          COLOR_SCLERA);
    gc9a01_fast_fill_rect(d2,
                          0,
                          new_y,
                          RECT_W,
                          RECT_H,
                          COLOR_SCLERA);

    // 3) Draw the new pupil
    gc9a01_fast_fill_rect(d1,
                          s->pupil_x,
                          new_y,
                          PUPIL_W,
                          PUPIL_H,
                          COLOR_PUPIL);
    gc9a01_fast_fill_rect(d2,
                          s->pupil_x,
                          new_y,
                          PUPIL_W,
                          PUPIL_H,
                          COLOR_PUPIL);

    // 4) Remember this draw as the "old" for next time
    s->rect_y_old  = new_y;
    s->pupil_x_old = s->pupil_x;
}

//------------------------------------------------------------------------------
// Exactly as in FrontMan.c:
// Draw a scaled‐eye (always clears entire screen first)
//------------------------------------------------------------------------------
static void draw_eye_scaled(EyeState *state, float sclera_scale, float pupil_scale) {
    int sclera_h = (int)(RECT_H * sclera_scale + 0.5f);
    int sclera_y = state->rect_y + (RECT_H - sclera_h) / 2;
    int pupil_w  = (int)(PUPIL_W * pupil_scale + 0.5f);
    int pupil_x  = state->pupil_x + (PUPIL_W - pupil_w) / 2;

    gc9a01_fast_fill_rect(d1, 0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, COLOR_BG);
    gc9a01_fast_fill_rect(d2, 0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, COLOR_BG);

    gc9a01_fast_fill_rect(d1, 0, sclera_y, RECT_W, sclera_h, COLOR_SCLERA);
    gc9a01_fast_fill_rect(d2, 0, sclera_y, RECT_W, sclera_h, COLOR_SCLERA);
    gc9a01_fast_fill_rect(d1, pupil_x, sclera_y, pupil_w, sclera_h, COLOR_PUPIL);
    gc9a01_fast_fill_rect(d2, pupil_x, sclera_y, pupil_w, sclera_h, COLOR_PUPIL);
}

//------------------------------------------------------------------------------
// Pick new random targets
//------------------------------------------------------------------------------
static void pick_new_targets(EyeState *state) {
    state->rect_y_target  = MIN_Y + rand() % (MAX_Y - MIN_Y + 1);
    state->pupil_x_target = MIN_X + rand() % (MAX_X - MIN_X + 1);
}

//------------------------------------------------------------------------------
// Smooth‐step interpolation
//------------------------------------------------------------------------------
static void do_smooth_step(EyeState *state) {
    clear_old_eye(state);
    state->rect_y_f  += state->rect_y_step;
    state->pupil_x_f += state->pupil_x_step;

    state->rect_y_old  = state->rect_y;
    state->pupil_x_old = state->pupil_x;
    state->rect_y      = (int)(state->rect_y_f + 0.5f);
    state->pupil_x     = (int)(state->pupil_x_f + 0.5f);

    draw_eye(state);
    state->smooth_step_count++;
}

//------------------------------------------------------------------------------
// Public API
//------------------------------------------------------------------------------

void setup_initial_eyes(DisplayPins* disp1, DisplayPins* disp2) {
    d1 = disp1;
    d2 = disp2;
    srand(to_us_since_boot(get_absolute_time()));

    eye_state.rect_y      = eye_state.rect_y_old  = (MIN_Y + MAX_Y) / 2;
    eye_state.pupil_x     = eye_state.pupil_x_old = (MIN_X + MAX_X) / 2;
    eye_state.phase       = EYE_FIXATE;
    eye_state.until       = delayed_by_ms(get_absolute_time(), 500);

    gc9a01_fast_fill_rect(d1, 0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, COLOR_BG);
    gc9a01_fast_fill_rect(d2, 0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, COLOR_BG);
    draw_eye(&eye_state);

    stare_trigger_time = delayed_by_ms(get_absolute_time(), random_stare_period());
    next_blink_time    = delayed_by_ms(get_absolute_time(), 3000 + rand() % 3000);
    next_eye_frame     = get_absolute_time();
}

void refresh_initial_eyes(void) {
    if (current_mode == MODE_STARE) {
        draw_eye_scaled(&eye_state, last_sclera_scale, last_pupil_scale);
    } else {
        draw_eye(&eye_state);
    }
}

void update_initial_eyes(void) {
    absolute_time_t now = get_absolute_time();
    if (!time_passed(now, next_eye_frame)) return;
    next_eye_frame = delayed_by_ms(now, 2);

    // 1) Blink
    if (!in_blink && time_passed(now, next_blink_time)) {
        in_blink       = true;
        blink_on       = true;
        blink_end_time = delayed_by_ms(now, 125);
        gc9a01_fast_fill_rect(d1, 0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, COLOR_BG);
        gc9a01_fast_fill_rect(d2, 0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, COLOR_BG);
        return;
    }
    if (in_blink && time_passed(now, blink_end_time)) {
        if (blink_on) {
            draw_eye_scaled(&eye_state, last_sclera_scale, last_pupil_scale);
            blink_on       = false;
            blink_end_time = delayed_by_ms(now, 125);
        } else {
            in_blink       = false;
            next_blink_time = delayed_by_ms(now, 3000 + rand() % 3000);
        }
        return;
    }

    // 2) Stare
    if (current_mode == MODE_NORMAL && time_passed(now, stare_trigger_time)) {
        current_mode   = MODE_STARE;
        stare_type     = (rand() % 2 == 0) ? STARE_CONTRACT : STARE_EXPAND;
        stare_end_time = delayed_by_ms(now, STARE_DURATION_MS);
        return;
    }
    if (current_mode == MODE_STARE) {
        int ms_stared = (int)(to_ms_since_boot(now)
                           - to_ms_since_boot(stare_end_time)
                           + STARE_DURATION_MS);
        float sclera_scale = 1.0f, pupil_scale = 1.0f;

        // contract/expand exactly as original:
        if (stare_type == STARE_CONTRACT) {
            if (ms_stared < STARE_CONTRACT_START) {
                sclera_scale = pupil_scale = 1.0f;
            } else if (ms_stared < STARE_CONTRACT_END) {
                float t = (ms_stared - STARE_CONTRACT_START) /
                          (STARE_CONTRACT_END - STARE_CONTRACT_START);
                sclera_scale = pupil_scale = 1.0f - t * 0.5f;
            } else if (ms_stared < STARE_HOLD_END) {
                sclera_scale = pupil_scale = 0.5f;
            } else if (ms_stared < STARE_RELAX_END) {
                float t = (ms_stared - STARE_HOLD_END) /
                          (STARE_RELAX_END   - STARE_HOLD_END);
                sclera_scale = pupil_scale = 0.5f + t * 0.5f;
            }
        } else {
            if (ms_stared < STARE_CONTRACT_START) {
                sclera_scale = pupil_scale = 1.0f;
            } else if (ms_stared < STARE_CONTRACT_END) {
                float t = (ms_stared - STARE_CONTRACT_START) /
                          (STARE_CONTRACT_END - STARE_CONTRACT_START);
                sclera_scale = pupil_scale = 1.0f + t * 1.0f;
            } else if (ms_stared < STARE_HOLD_END) {
                sclera_scale = pupil_scale = 2.0f;
            } else if (ms_stared < STARE_RELAX_END) {
                float t = (ms_stared - STARE_HOLD_END) /
                          (STARE_RELAX_END   - STARE_HOLD_END);
                sclera_scale = pupil_scale = 2.0f - t * 1.0f;
            }
        }

        if (fabsf(sclera_scale - last_sclera_scale) > 0.01f ||
            fabsf(pupil_scale  - last_pupil_scale)  > 0.01f) {
            draw_eye_scaled(&eye_state, sclera_scale, pupil_scale);
            last_sclera_scale = sclera_scale;
            last_pupil_scale  = pupil_scale;
        }

        if (ms_stared >= STARE_RELAX_END) {
            current_mode      = MODE_COOLDOWN;
            cooldown_end_time = delayed_by_ms(now, STARE_COOLDOWN_MS);
        }
        return;
    }

    // 3) Cooldown
    if (current_mode == MODE_COOLDOWN) {
        if (fabsf(last_sclera_scale - 1.0f) > 0.01f ||
            fabsf(last_pupil_scale  - 1.0f) > 0.01f) {
            draw_eye_scaled(&eye_state, 1.0f, 1.0f);
            last_sclera_scale = last_pupil_scale = 1.0f;
        }
        if (time_passed(now, cooldown_end_time)) {
            current_mode       = MODE_NORMAL;
            stare_trigger_time = delayed_by_ms(now, random_stare_period());
            clear_old_eye(&eye_state);
            draw_eye(&eye_state);
        }
        return;
    }

    // 4) Fixate → Saccade / Smooth
    if (eye_state.phase == EYE_FIXATE && time_passed(now, eye_state.until)) {
        pick_new_targets(&eye_state);
        if (rand() % 5 < 3) {
            eye_state.smooth_steps      = 8 + rand() % 7;
            eye_state.smooth_step_count = 0;
            eye_state.rect_y_f          = eye_state.rect_y;
            eye_state.pupil_x_f         = eye_state.pupil_x;
            eye_state.rect_y_step       =
                (eye_state.rect_y_target - eye_state.rect_y)
                / (float)eye_state.smooth_steps;
            eye_state.pupil_x_step      =
                (eye_state.pupil_x_target - eye_state.pupil_x)
                / (float)eye_state.smooth_steps;
            next_smooth_step_time       = now;
            eye_state.phase             = EYE_SMOOTH;
        } else {
            eye_state.phase = EYE_SACCADE;
        }
    }
    else if (eye_state.phase == EYE_SACCADE) {
        clear_old_eye(&eye_state);
        // update old *and* current in one go, just like the original
        eye_state.rect_y_old   = eye_state.rect_y   = eye_state.rect_y_target;
        eye_state.pupil_x_old  = eye_state.pupil_x  = eye_state.pupil_x_target;
        draw_eye(&eye_state);
        eye_state.until      = delayed_by_ms(now, 400 + rand() % 1400);
        eye_state.phase      = EYE_FIXATE;
    }
    else if (eye_state.phase == EYE_SMOOTH) {
        if (eye_state.smooth_step_count < eye_state.smooth_steps &&
            time_passed(now, next_smooth_step_time)) {
            do_smooth_step(&eye_state);
            next_smooth_step_time =
                delayed_by_ms(now, 6 + rand() % 7);
        } else {
            clear_old_eye(&eye_state);
            // update old *and* current in one go, just like the original
            eye_state.rect_y_old   = eye_state.rect_y   = eye_state.rect_y_target;
            eye_state.pupil_x_old  = eye_state.pupil_x  = eye_state.pupil_x_target;
            draw_eye(&eye_state);
            eye_state.until = delayed_by_ms(now, 400 + rand() % 1400);
            eye_state.phase = EYE_FIXATE;
        }
    }
}
