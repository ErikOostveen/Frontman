#ifndef ANGRY_EYES_H
#define ANGRY_EYES_H

#include <stdint.h>
#include "gc9a01.h"
#include "pico/time.h"

// Color globals (from FrontMan.c)
extern uint16_t COLOR_SCLERA;
extern uint16_t COLOR_PUPIL;

// Initialize and draw the angry circles using COLOR_SCLERA and COLOR_PUPIL
void setup_angry_eyes(DisplayPins* disp1, DisplayPins* disp2);

// No per‐frame animation needed
void update_angry_eyes(void);

// Redraw on color change
void refresh_angry_eyes(void);

#endif // ANGRY_EYES_H