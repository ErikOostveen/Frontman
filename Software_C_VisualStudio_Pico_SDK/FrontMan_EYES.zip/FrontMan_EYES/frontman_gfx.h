#ifndef FRONTMAN_GFX_H
#define FRONTMAN_GFX_H

#include <stdint.h>
#include "gc9a01.h"
#include "pico/sync.h"

// Basic drawing functions
void gfx_fill_screen(DisplayPins* disp, uint16_t color, mutex_t* mtx);
void gfx_fill_rect(DisplayPins* disp, int x, int y, int w, int h, uint16_t color, mutex_t* mtx);
void gfx_draw_rect(DisplayPins* disp, int x, int y, int w, int h, uint16_t color, mutex_t* mtx);
void gfx_fill_circle(DisplayPins* disp, int x0, int y0, int r, uint16_t color, mutex_t* mtx);
void gfx_draw_circle(DisplayPins* disp, int x0, int y0, int r, uint16_t color, mutex_t* mtx);
void gfx_draw_pixel(DisplayPins* disp, int x, int y, uint16_t color, mutex_t* mtx);
void gfx_draw_line(DisplayPins* disp, int x0, int y0, int x1, int y1, uint16_t color, mutex_t* mtx);
void gfx_draw_triangle(DisplayPins* disp, int x0, int y0, int x1, int y1, int x2, int y2, uint16_t color, mutex_t* mtx);
void gfx_fill_triangle(DisplayPins* disp, int x0, int y0, int x1, int y1, int x2, int y2, uint16_t color, mutex_t* mtx);

// Arc (outline, not filled)
void gfx_draw_arc(DisplayPins* disp, int x0, int y0, int r, int start_angle, int end_angle, uint16_t color, mutex_t* mtx);

// RGB888 to 565 color macro (same as before)
#define BGR565(r,g,b)   ( ((b & 0xF8) << 8) | ((g & 0xFC) << 3) | ((r) >> 3) )

#endif
