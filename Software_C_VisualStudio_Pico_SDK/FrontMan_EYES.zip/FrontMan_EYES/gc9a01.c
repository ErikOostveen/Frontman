#include "gc9a01.h"
#include "hardware/spi.h"
#include "hardware/gpio.h"

// SPI and pin setup
void gc9a01_spi_init(void) {
    spi_init(SPI_PORT, 80 * 1000 * 1000);
    spi_set_format(SPI_PORT, 8, SPI_CPOL_0, SPI_CPHA_0, SPI_MSB_FIRST);

    gpio_set_function(PIN_SCK, GPIO_FUNC_SPI);
    gpio_set_function(PIN_MOSI, GPIO_FUNC_SPI);
}

// Low-level helpers
static void send_command(DisplayPins* d, uint8_t cmd) {
    gpio_put(d->dc, 0);
    gpio_put(d->cs, 0);
    spi_write_blocking(SPI_PORT, &cmd, 1);
    gpio_put(d->cs, 1);
}
static void send_data(DisplayPins* d, const uint8_t* data, size_t len) {
    gpio_put(d->dc, 1);
    gpio_put(d->cs, 0);
    spi_write_blocking(SPI_PORT, data, len);
    gpio_put(d->cs, 1);
}
static void reset_display(DisplayPins* d) {
    gpio_init(d->cs);  gpio_set_dir(d->cs, GPIO_OUT);   gpio_put(d->cs, 1);
    gpio_init(d->dc);  gpio_set_dir(d->dc, GPIO_OUT);   gpio_put(d->dc, 1);
    gpio_init(d->rst); gpio_set_dir(d->rst, GPIO_OUT);  gpio_put(d->rst, 1);

    gpio_put(d->rst, 0); sleep_ms(4);
    gpio_put(d->rst, 1); sleep_ms(4);
}

// Full GC9A01 init sequence
void gc9a01_init(DisplayPins* d) {
    reset_display(d);

    send_command(d,0xEF);
    send_command(d,0xEB); uint8_t d_eb1[]={0x14}; send_data(d,d_eb1,1);
    send_command(d,0xFE); send_command(d,0xEF);
    send_command(d,0xEB); uint8_t d_eb2[]={0x14}; send_data(d,d_eb2,1);
    send_command(d,0x84); uint8_t d_84[]={0x40}; send_data(d,d_84,1);
    send_command(d,0x85); uint8_t d_85[]={0xFF}; send_data(d,d_85,1);
    send_command(d,0x86); uint8_t d_86[]={0xFF}; send_data(d,d_86,1);
    send_command(d,0x87); uint8_t d_87[]={0xFF}; send_data(d,d_87,1);
    send_command(d,0x88); uint8_t d_88[]={0x0A}; send_data(d,d_88,1);
    send_command(d,0x89); uint8_t d_89[]={0x21}; send_data(d,d_89,1);
    send_command(d,0x8A); uint8_t d_8A[]={0x00}; send_data(d,d_8A,1);
    send_command(d,0x8B); uint8_t d_8B[]={0x80}; send_data(d,d_8B,1);
    send_command(d,0x8C); uint8_t d_8C[]={0x01}; send_data(d,d_8C,1);
    send_command(d,0x8D); uint8_t d_8D[]={0x01}; send_data(d,d_8D,1);
    send_command(d,0x8E); uint8_t d_8E[]={0xFF}; send_data(d,d_8E,1);
    send_command(d,0x8F); uint8_t d_8F[]={0xFF}; send_data(d,d_8F,1);
    send_command(d,0xB6); uint8_t d_b6[]={0x00,0x20}; send_data(d,d_b6,2);
    send_command(d,0x3A); uint8_t d_3a[]={0x05}; send_data(d,d_3a,1);
    send_command(d,0x90); uint8_t d_90[]={0x08,0x08,0x08,0x08}; send_data(d,d_90,4);
    send_command(d,0xBD); uint8_t d_bd[]={0x06}; send_data(d,d_bd,1);
    send_command(d,0xBC); uint8_t d_bc[]={0x00}; send_data(d,d_bc,1);
    send_command(d,0xFF); uint8_t d_ff[]={0x60,0x01,0x04}; send_data(d,d_ff,3);
    send_command(d,0xC3); uint8_t d_c3[]={0x13}; send_data(d,d_c3,1);
    send_command(d,0xC4); uint8_t d_c4[]={0x13}; send_data(d,d_c4,1);
    send_command(d,0xC9); uint8_t d_c9[]={0x22}; send_data(d,d_c9,1);
    send_command(d,0xBE); uint8_t d_be[]={0x11}; send_data(d,d_be,1);
    send_command(d,0xE1); uint8_t d_e1[]={0x10,0x0E}; send_data(d,d_e1,2);
    send_command(d,0xDF); uint8_t d_df[]={0x21,0x0c,0x02}; send_data(d,d_df,3);
    send_command(d,0xF0); uint8_t d_f0[]={0x45,0x09,0x08,0x08,0x26,0x2A}; send_data(d,d_f0,6);
    send_command(d,0xF1); uint8_t d_f1[]={0x43,0x70,0x72,0x36,0x37,0x6F}; send_data(d,d_f1,6);
    send_command(d,0xF2); uint8_t d_f2[]={0x45,0x09,0x08,0x08,0x26,0x2A}; send_data(d,d_f2,6);
    send_command(d,0xF3); uint8_t d_f3[]={0x43,0x70,0x72,0x36,0x37,0x6F}; send_data(d,d_f3,6);
    send_command(d,0xED); uint8_t d_ed[]={0x1B,0x0B}; send_data(d,d_ed,2);
    send_command(d,0xAE); uint8_t d_ae[]={0x77}; send_data(d,d_ae,1);
    send_command(d,0xCD); uint8_t d_cd[]={0x63}; send_data(d,d_cd,1);
    send_command(d,0x70); uint8_t d_70[]={0x07,0x07,0x04,0x0E,0x0F,0x09,0x07,0x08,0x03}; send_data(d,d_70,9);
    send_command(d,0xE8); uint8_t d_e8[]={0x34}; send_data(d,d_e8,1);
    send_command(d,0x62); uint8_t d_62[]={0x18,0x0D,0x71,0xED,0x70,0x70,0x18,0x0F,0x71,0xEF,0x70,0x70}; send_data(d,d_62,12);
    send_command(d,0x63); uint8_t d_63[]={0x18,0x11,0x71,0xF1,0x70,0x70,0x18,0x13,0x71,0xF3,0x70,0x70}; send_data(d,d_63,12);
    send_command(d,0x64); uint8_t d_64[]={0x28,0x29,0xF1,0x01,0xF1,0x00,0x07}; send_data(d,d_64,7);
    send_command(d,0x66); uint8_t d_66[]={0x3C,0x00,0xCD,0x67,0x45,0x45,0x10,0x00,0x00,0x00}; send_data(d,d_66,10);
    send_command(d,0x67); uint8_t d_67[]={0x00,0x3C,0x00,0x00,0x00,0x01,0x54,0x10,0x32,0x98}; send_data(d,d_67,10);
    send_command(d,0x74); uint8_t d_74[]={0x10,0x85,0x80,0x00,0x00,0x4E,0x00}; send_data(d,d_74,7);
    send_command(d,0x98); uint8_t d_98[]={0x3e,0x07}; send_data(d,d_98,2);
    send_command(d,0x35); send_command(d,0x21);
    send_command(d,0x11); sleep_ms(4);
    send_command(d,0x29); sleep_ms(4);
}

// Set address window for drawing
static void set_addr_window(DisplayPins* d, uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1) {
    uint8_t data[4];
    send_command(d, 0x2A);
    data[0] = x0 >> 8; data[1] = x0 & 0xFF; data[2] = x1 >> 8; data[3] = x1 & 0xFF;
    send_data(d, data, 4);
    send_command(d, 0x2B);
    data[0] = y0 >> 8; data[1] = y0 & 0xFF; data[2] = y1 >> 8; data[3] = y1 & 0xFF;
    send_data(d, data, 4);
    send_command(d, 0x2C);
}

// Fast fill rectangle (batched writes)
void gc9a01_fast_fill_rect(DisplayPins* d, uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t color) {
    set_addr_window(d, x, y, x+w-1, y+h-1);
    size_t count = w * h;
    static uint8_t buf[1024]; // 512 pixels at a time
    uint8_t hi = color >> 8, lo = color & 0xFF;
    for (int i = 0; i < sizeof(buf); i += 2) {
        buf[i] = hi;
        buf[i+1] = lo;
    }
    while (count > 0) {
        size_t batch = count > (sizeof(buf)/2) ? (sizeof(buf)/2) : count;
        send_data(d, buf, batch*2);
        count -= batch;
    }
}
