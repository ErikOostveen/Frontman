// eye_colors.h

#ifndef EYE_COLORS_H
#define EYE_COLORS_H

#include "gc9a01.h"  // for BGR565 macro

typedef struct {
    uint16_t pupil;
    uint16_t sclera;
} EyeColorScheme;

#define NUM_COLOR_SCHEMES 100

static const EyeColorScheme color_schemes[NUM_COLOR_SCHEMES] = {
    // 1. Golden Eagle (default)
    { BGR565(255, 215, 0), BGR565(80, 40, 0) },

    // 2. Blue
    { BGR565(0, 0, 255), BGR565(100, 149, 237) },

    // 3. Black Evil
    { BGR565(0, 0, 0), BGR565(255, 0, 0) },

    // 4. Silver Storm
    { BGR565(192, 192, 192), BGR565(105, 105, 105) },

    // 5. Arctic Ice
    { BGR565(0, 255, 255), BGR565(224, 255, 255) },

    // 6. Forest
    { BGR565(0, 100, 0), BGR565(144, 238, 144) },

    // 7. Sunset Blaze
    { BGR565(255, 69, 0), BGR565(255, 160, 122) },

    // 8. Toxic Green
    { BGR565(173, 255, 47), BGR565(34, 139, 34) },

    // 9. Royal Purple
    { BGR565(128, 0, 128), BGR565(221, 160, 221) },

    // 10. Pink Demon
    { BGR565(255, 20, 147), BGR565(255, 182, 193) },

    // 11. Ice Demon
    { BGR565(0, 255, 255), BGR565(0, 0, 0) },

    // 12. Molten Core
    { BGR565(255, 140, 0), BGR565(178, 34, 34) },

    // 13. Steampunk Brass
    { BGR565(184, 134, 11), BGR565(205, 133, 63) },

    // 14. Alien Glow
    { BGR565(50, 205, 50), BGR565(0, 0, 0) },

    // 15. Sapphire Soul
    { BGR565(65, 105, 225), BGR565(176, 224, 230) },

    // 16. Fireburst
    { BGR565(255, 0, 0), BGR565(255, 255, 0) },

    // 17. Witch’s Gaze
    { BGR565(75, 0, 130), BGR565(186, 85, 211) },

    // 18. Chrome Alloy
    { BGR565(192, 192, 192), BGR565(169, 169, 169) },

    // 19. Ember Eye
    { BGR565(255, 69, 0), BGR565(255, 228, 181) },

    // 20. Aqua Pop
    { BGR565(0, 255, 127), BGR565(0, 191, 255) },

    // 21–50 (more creative combinations)
    { BGR565(255, 255, 255), BGR565(0, 0, 0) }, // 21. Invert
    { BGR565(255, 0, 255), BGR565(75, 0, 130) }, // 22. Magenta Dream
    { BGR565(255, 255, 240), BGR565(112, 128, 144) }, // 23. Foggy Eye
    { BGR565(0, 191, 255), BGR565(25, 25, 112) }, // 24. Night Ocean
    { BGR565(255, 248, 220), BGR565(210, 105, 30) }, // 25. Caramel Cream
    { BGR565(199, 21, 133), BGR565(255, 228, 225) }, // 26. Rosy Blush
    { BGR565(70, 130, 180), BGR565(255, 255, 255) }, // 27. Ice Steel
    { BGR565(34, 139, 34), BGR565(85, 107, 47) }, // 28. Jungle Eye
    { BGR565(220, 20, 60), BGR565(255, 160, 122) }, // 29. Blazing Rose
    { BGR565(255, 255, 255), BGR565(128, 0, 0) }, // 30. Blood Moon

    { BGR565(0, 0, 0), BGR565(211, 211, 211) }, // 31. Grayscale Flip
    { BGR565(255, 255, 0), BGR565(0, 0, 128) }, // 32. Electric Navy
    { BGR565(0, 255, 127), BGR565(128, 128, 0) }, // 33. Acid Lime
    { BGR565(255, 105, 180), BGR565(139, 0, 139) }, // 34. Dark Fairy
    { BGR565(100, 149, 237), BGR565(240, 248, 255) }, // 35. Skyy
    { BGR565(139, 69, 19), BGR565(222, 184, 135) }, // 36. Earthroot
    { BGR565(30, 144, 255), BGR565(70, 130, 180) }, // 37. Denim
    { BGR565(255, 69, 0), BGR565(255, 235, 205) }, // 38. Cream Cinder
    { BGR565(255, 255, 224), BGR565(25, 25, 112) }, // 39. Moonlight
    { BGR565(0, 255, 0), BGR565(0, 0, 0) }, // 40. Hacker Eye

    { BGR565(0, 0, 255), BGR565(255, 255, 255) }, // 41. Polar Pop
    { BGR565(255, 192, 203), BGR565(255, 250, 250) }, // 42. Snow Blush
    { BGR565(75, 0, 130), BGR565(230, 230, 250) }, // 43. Lavender Storm
    { BGR565(255, 99, 71), BGR565(255, 239, 213) }, // 44. Coral Cloud
    { BGR565(255, 20, 147), BGR565(255, 250, 240) }, // 45. Dainty Demon
    { BGR565(46, 100, 244), BGR565(255, 255, 0) }, // 46. Your Original
    { BGR565(255, 215, 0), BGR565(0, 0, 0) }, // 47. Gold Void
    { BGR565(255, 255, 0), BGR565(255, 0, 255) }, // 48. Warped Rainbow
    { BGR565(34, 139, 34), BGR565(255, 255, 255) }, // 49. Inverse Forest
    { BGR565(255, 250, 205), BGR565(105, 105, 105) }, // 50. Soft Coal

    // 51. Neon Fusion
    { BGR565(255,0,255),   BGR565(0,255,255)  },
    // 52. Laser Grid
    { BGR565(0,255,0),     BGR565(255,0,0)    },
    // 53. Cyber Acid
    { BGR565(0, 255,127),  BGR565(255,0,255)  },
    // 54. Glitch Pink
    { BGR565(255,105,180), BGR565(0,255,255)  },
    // 55. UV Flash
    { BGR565(102,0,255),   BGR565(255,255,0)  },
    // 56. Infra Red
    { BGR565(255,0,0),     BGR565(0,0,0)      },
    // 57. Radioactive
    { BGR565(50,205,50),   BGR565(0,0,0)      },
    // 58. Toxic Slime
    { BGR565(127,255,0),   BGR565(0,51,0)     },
    // 59. Acid Trip
    { BGR565(255,0,127),   BGR565(127,0,255)  },
    // 60. Magma Core
    { BGR565(255,69,0),    BGR565(139,0,0)    },
    // 61. Electric Bolt
    { BGR565(255,255,0),   BGR565(0,0,128)    },
    // 62. Plasma Blue
    { BGR565(0,191,255),   BGR565(0,0,64)     },
    // 63. Solar Flare
    { BGR565(255,102,0),   BGR565(128,0,0)    },
    // 64. Quantum Red
    { BGR565(255,0,0),     BGR565(64,0,0)     },
    // 65. Neon Drip
    { BGR565(0,255,255),   BGR565(255,0,255)  },
    // 66. Glitch Green
    { BGR565(0,255,0),     BGR565(0,64,0)     },
    // 67. Holographic
    { BGR565(255,0,255),   BGR565(0,255,0)    },
    // 68. Acid Purple
    { BGR565(127,0,255),   BGR565(0,127,255)  },
    // 69. Toxic Sunset
    { BGR565(255,0,127),   BGR565(255,255,0)  },
    // 70. Electric Lemon
    { BGR565(255,255,0),   BGR565(64,64,0)    },
    // 71. Digital Rain
    { BGR565(0,255,127),   BGR565(0,127,255)  },
    // 72. Cosmic Pink
    { BGR565(255,0,255),   BGR565(255,127,255) },
    // 73. Biohazard
    { BGR565(0,100,0),     BGR565(0,0,0)      },
    // 74. Plasma Core
    { BGR565(255,255,102), BGR565(102,0,255)  },
    // 75. Neon Citrus
    { BGR565(255,255,0),   BGR565(255,127,0)  },
    // 76. Arctic Shock
    { BGR565(0,255,255),   BGR565(0,127,127)  },
    // 77. Inferno
    { BGR565(255,69,0),    BGR565(139,0,0)    },
    // 78. Glitch Gold
    { BGR565(255,215,0),   BGR565(128,64,0)   },
    // 79. Ultraviolet
    { BGR565(138,43,226),  BGR565(75,0,130)   },
    // 80. Toxic Pink
    { BGR565(255,20,147),  BGR565(127,0,73)   },
    // 81. Neon Night
    { BGR565(0,128,255),   BGR565(0,0,64)     },
    // 82. Techno Green
    { BGR565(0,255,0),     BGR565(0,64,0)     },
    // 83. Acid Orange
    { BGR565(255,165,0),   BGR565(127,82,0)   },
    // 84. Digital Purple
    { BGR565(127,0,255),   BGR565(64,0,128)   },
    // 85. Solar Punk
    { BGR565(255,255,0),   BGR565(0,128,0)    },
    // 86. Neon Coral
    { BGR565(255,127,80),  BGR565(127,64,40)  },
    // 87. Reactor Blue
    { BGR565(0,191,255),   BGR565(0,0,64)     },
    // 88. Plasma Green
    { BGR565(0,255,127),   BGR565(0,64,32)    },
    // 89. Glitch Yellow
    { BGR565(255,255,0),   BGR565(127,127,0)  },
    // 90. Toxic Red
    { BGR565(255,0,0),     BGR565(127,0,0)    },
    // 91. Cyber Wave
    { BGR565(0,128,255),   BGR565(128,0,255)  },
    // 92. Neon Ember
    { BGR565(255,69,0),    BGR565(255,127,0)  },
    // 93. Quantum Green
    { BGR565(0,255,127),   BGR565(0,127,64)   },
    // 94. Galactic Purple
    { BGR565(138,43,226),  BGR565(75,0,130)   },
    // 95. Infernal Blue
    { BGR565(0,0,255),     BGR565(0,0,127)    },
    // 96. Bio Green
    { BGR565(0,255,0),     BGR565(0,127,0)    },
    // 97. Solar Red
    { BGR565(255,0,0),     BGR565(127,0,0)    },
    // 98. Cosmic Yellow
    { BGR565(255,255,0),   BGR565(127,127,0)  },
    // 99. Neon Chic
    { BGR565(255,0,255),   BGR565(127,0,127)  },
    // 100. Ultra Violet
    { BGR565(143,0,255),   BGR565(71,0,127)   },
};

#endif // EYE_COLORS_H
