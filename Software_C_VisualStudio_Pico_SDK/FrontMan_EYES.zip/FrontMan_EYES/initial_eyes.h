#ifndef INITIAL_EYES_H
#define INITIAL_EYES_H

#include <stdint.h>
#include "gc9a01.h"
#include "pico/time.h"

// These live in FrontMan.c:
extern uint16_t COLOR_SCLERA;
extern uint16_t COLOR_PUPIL;

// Initialize the two displays and draw the first frame.
void setup_initial_eyes(DisplayPins* disp1, DisplayPins* disp2);

// Call once per iteration of your main loop.
void update_initial_eyes(void);

// Call when COLOR_SCLERA / COLOR_PUPIL change.
void refresh_initial_eyes(void);

#endif // INITIAL_EYES_H

