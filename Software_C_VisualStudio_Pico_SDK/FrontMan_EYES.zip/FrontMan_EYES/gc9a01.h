#ifndef GC9A01_H
#define GC9A01_H

#include "pico/stdlib.h"

// Structure for pin assignments per display
typedef struct {
    uint cs, dc, rst;
} DisplayPins;

// Pin constants and SPI port for shared bus
#define PIN_SCK   14
#define PIN_MOSI  15
#define SPI_PORT  spi1
#define SCREEN_WIDTH  240
#define SCREEN_HEIGHT 240

// Macro: BGR565 (accepts standard RGB order, but swaps R/B)
#define BGR565(r,g,b)  ( ((b & 0xF8) << 8) | ((g & 0xFC) << 3) | ((r) >> 3) )

// Color defines
#define COLOR_RED     BGR565(255,0,0)
#define COLOR_GREEN   BGR565(0,255,0)
#define COLOR_BLUE    BGR565(0,0,255)
#define COLOR_WHITE   BGR565(255,255,255)
#define COLOR_BLACK   BGR565(0,0,0)
#define COLOR_YELLOW  BGR565(255,255,0)
#define COLOR_CYAN    BGR565(0,255,255)
#define COLOR_MAGENTA BGR565(255,0,255)


void gc9a01_spi_init(void);
void gc9a01_init(DisplayPins* d);
void gc9a01_fast_fill_rect(DisplayPins* d, uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t color);

#endif // GC9A01_H
