#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include "pico/stdlib.h"
#include "hardware/pwm.h"
#include "gc9a01.h"
#include "hardware/uart.h"
#include "eye_colors.h"
#include "pico/time.h"
#include "initial_eyes.h"
#include "angry_eyes.h"





static absolute_time_t last_user_input_time = { 0 };
static absolute_time_t last_auto_action_time = { 0 };






//==============================================================================
// Color definitions (modifiable via rotary encoder)
//==============================================================================
uint16_t COLOR_SCLERA = BGR565(80, 40, 0);
uint16_t COLOR_PUPIL  = BGR565(255, 215, 0);

volatile bool color_scheme_changed = false;  // flag to redraw eyes

//==============================================================================
// Which eye module to run: 0 = initial_eyes, 1 = angry_eyes
//==============================================================================
int eye_select_index = 0;

//==============================================================================
// Displays
//==============================================================================
DisplayPins disp1 = { .cs = 5, .dc = 4, .rst = 6 };
DisplayPins disp2 = { .cs = 9, .dc = 8, .rst = 10 };

//==============================================================================
// Encoder & UART
//==============================================================================
#define ENCODER_BUTTON_PIN 2
#define ENCODER_A_PIN      1
#define ENCODER_B_PIN      19

#define ROTARY_MIN 1
#define ROTARY_MAX 100

#define UART_ID       uart0
#define UART_TX_PIN   16
#define UART_RX_PIN   17
#define UART_BAUDRATE 115200

static absolute_time_t last_button_time = { 0 };
#define DEBOUNCE_MS 20

volatile int  RotaryValue      = 1;
volatile bool encoder_wants_send = false;
volatile int  last_rotary_value  = 1;

void uart_send_int(const char *label, int value) {
    char buf[64];
    int len = snprintf(buf, sizeof(buf), "%s%d\n", label, value);
    uart_write_blocking(UART_ID, (uint8_t*)buf, len);
}

void encoder_irq_handler(uint gpio, uint32_t events) {



    last_user_input_time = get_absolute_time();  // Reset inactivity timer



    static absolute_time_t last_irq = { 0 };
    absolute_time_t now = get_absolute_time();
    if (absolute_time_diff_us(last_irq, now) < DEBOUNCE_MS*1000) return;
    last_irq = now;

    bool A = gpio_get(ENCODER_A_PIN), B = gpio_get(ENCODER_B_PIN);
    if (events & GPIO_IRQ_EDGE_FALL) {
        if (A != B) {
            if (RotaryValue < ROTARY_MAX) RotaryValue++;
        } else {
            if (RotaryValue > ROTARY_MIN) RotaryValue--;
        }
        int idx = RotaryValue - 1;
        COLOR_PUPIL  = color_schemes[idx].pupil;
        COLOR_SCLERA = color_schemes[idx].sclera;
        color_scheme_changed = true;
        last_rotary_value    = RotaryValue;
        encoder_wants_send   = true;
    }
}

void init_encoder(void) {
    gpio_init(ENCODER_A_PIN);
    gpio_set_dir(ENCODER_A_PIN, GPIO_IN);
    gpio_pull_up(ENCODER_A_PIN);

    gpio_init(ENCODER_B_PIN);
    gpio_set_dir(ENCODER_B_PIN, GPIO_IN);
    gpio_pull_up(ENCODER_B_PIN);

    gpio_set_irq_enabled_with_callback(
        ENCODER_A_PIN,
        GPIO_IRQ_EDGE_FALL,
        true,
        &encoder_irq_handler
    );
}

void init_uart(void) {
    uart_init(UART_ID, UART_BAUDRATE);
    gpio_set_function(UART_TX_PIN, GPIO_FUNC_UART);
    gpio_set_function(UART_RX_PIN, GPIO_FUNC_UART);
}

//==============================================================================
// PWM LED
//==============================================================================
#define LED1_PIN 11
#define LED2_PIN 12
#define LED3_PIN 13

typedef struct {
    uint        pin;
    uint        slice_num;
    uint32_t    last_toggle_time;
    uint32_t    cycle_time;
    uint32_t    fade_time;
    bool        fade_in;
    uint16_t    duty;
} pwm_led_t;

void init_pwm_led(pwm_led_t *led) {
    gpio_set_function(led->pin, GPIO_FUNC_PWM);
    led->slice_num = pwm_gpio_to_slice_num(led->pin);
    pwm_set_wrap(led->slice_num, 1000);
    pwm_set_clkdiv(led->slice_num, 125);
    pwm_set_enabled(led->slice_num, true);

    led->duty             = 0;
    led->fade_in          = true;
    led->last_toggle_time = to_ms_since_boot(get_absolute_time());
}

void fade_pwm_led(pwm_led_t *led, uint32_t now_ms) {
    if (now_ms - led->last_toggle_time < led->cycle_time) return;
    led->last_toggle_time = now_ms;
    uint16_t step = led->fade_time ? (1000 / led->fade_time) : 1;
    if (led->fade_in) {
        if (led->duty + step <= 1000) led->duty += step;
        else led->duty = 1000;
    } else {
        if (led->duty >= step) led->duty -= step;
        else led->duty = 0;
    }
    pwm_set_gpio_level(led->pin, led->duty);
    if (led->fade_in && led->duty == 1000) led->fade_in = false;
    else if (!led->fade_in && led->duty == 0) led->fade_in = true;
}

static inline uint8_t duty_to_8(uint16_t duty) {
    return (uint8_t)((duty * 255) / 1000);
}

//==============================================================================
// main()
//==============================================================================
int main() {
    stdio_init_all();
    srand(to_us_since_boot(get_absolute_time()));

    // UART & encoder
    init_uart();
    init_encoder();
    gpio_init(ENCODER_BUTTON_PIN);
    gpio_set_dir(ENCODER_BUTTON_PIN, GPIO_IN);
    gpio_pull_up(ENCODER_BUTTON_PIN);

    // LEDs
    pwm_led_t led1 = { .pin = LED1_PIN },
             led2 = { .pin = LED2_PIN },
             led3 = { .pin = LED3_PIN };
    init_pwm_led(&led1);
    init_pwm_led(&led2);
    init_pwm_led(&led3);

    // initial fade intervals
    uint32_t now_ms = time_us_32() / 1000;
    uint32_t last_interval_ms = now_ms;
    int s1 = 3 + rand()%8, s2, s3;
    do { s2 = 3 + rand()%8; } while (s2 == s1);
    do { s3 = 3 + rand()%8; } while (s3 == s1 || s3 == s2);
    led1.fade_time = led1.cycle_time = s1 * 10;
    led2.fade_time = led2.cycle_time = s2 * 10;
    led3.fade_time = led3.cycle_time = s3 * 10;

    // Displays
    gc9a01_spi_init();
    gc9a01_init(&disp1);
    gc9a01_init(&disp2);

    // Eye setup
    if (eye_select_index == 0) {
        setup_initial_eyes(&disp1, &disp2);
    }
    else {
        setup_angry_eyes(&disp1, &disp2);
    }

    uint32_t last_led_uart_ms = now_ms;
    bool btn_was_pressed = false;

    // Main loop
    while (1) {
        // encoder button → M100
    bool btn = !gpio_get(ENCODER_BUTTON_PIN);
    if (btn && !btn_was_pressed) {
        absolute_time_t tnow = get_absolute_time();
        if (absolute_time_diff_us(last_button_time, tnow) >= DEBOUNCE_MS*1000) {
            // 1) pick a random eye index (0 or 1)
            eye_select_index = rand() & 1;   // same as rand()%2

            // 2) re-initialize that module
            if (eye_select_index == 0) {
                setup_initial_eyes(&disp1, &disp2);
            } else {
                setup_angry_eyes(&disp1, &disp2);
            }

            // 3) (optional) force a full redraw immediately
            color_scheme_changed = true;

            // 4) send M100 (unchanged)
            uart_send_int("M", 100);

            last_button_time = tnow;
            btn_was_pressed  = true;
        }
    }
    else if (!btn && btn_was_pressed) {
            absolute_time_t tnow = get_absolute_time();
            if (absolute_time_diff_us(last_button_time, tnow) >= DEBOUNCE_MS*1000) {
                btn_was_pressed = false;
                last_button_time = tnow;
            }
        }



            if (btn || encoder_wants_send) {
                last_user_input_time = get_absolute_time();  // Reset inactivity timer
        }





        // update LED intervals every 30s
        now_ms = time_us_32() / 1000;
        if (now_ms - last_interval_ms >= 30000) {
            last_interval_ms = now_ms;
            s1 = 3 + rand()%8;
            do { s2 = 3 + rand()%8; } while (s2 == s1);
            do { s3 = 3 + rand()%8; } while (s3 == s1 || s3 == s2);
            led1.fade_time = led1.cycle_time = s1 * 10;
            led2.fade_time = led2.cycle_time = s2 * 10;
            led3.fade_time = led3.cycle_time = s3 * 10;
        }

        // fade LEDs
        fade_pwm_led(&led1, now_ms);
        fade_pwm_led(&led2, now_ms);
        fade_pwm_led(&led3, now_ms);

        // redraw eyes on color change
        if (color_scheme_changed) {
            color_scheme_changed = false;
            if (eye_select_index == 0) {
                refresh_initial_eyes();
            } else {
                refresh_angry_eyes();
            }
        }

        // eye update
        if (eye_select_index == 0) {
            update_initial_eyes();
        } else {
            update_angry_eyes();
        }

        // send C<rotary> if needed
        if (encoder_wants_send) {
            encoder_wants_send = false;
            uart_send_int("C", last_rotary_value);
        }

        // send L<LED color> every 40ms
        if (now_ms - last_led_uart_ms >= 40) {
            last_led_uart_ms = now_ms;
            uint16_t tri = BGR565(
                duty_to_8(led1.duty),
                duty_to_8(led2.duty),
                duty_to_8(led3.duty)
            );
            uart_send_int("L", tri);
        }








    // automatic activity when idle
    absolute_time_t now = get_absolute_time();
    int64_t idle_time_ms = absolute_time_diff_us(last_user_input_time, now) / 1000;
    int64_t auto_time_ms = absolute_time_diff_us(last_auto_action_time, now) / 1000;

    if (idle_time_ms >= 90000 && auto_time_ms >= 15000) {
        last_auto_action_time = now;

        if (rand() % 2 == 0) {
            // Simulate encoder change
            RotaryValue = 1 + rand() % (ROTARY_MAX - ROTARY_MIN + 1);
            last_rotary_value = RotaryValue;
            COLOR_PUPIL  = color_schemes[RotaryValue - 1].pupil;
            COLOR_SCLERA = color_schemes[RotaryValue - 1].sclera;
            color_scheme_changed = true;
            encoder_wants_send   = true;
        } else {
            // Simulate button press
            eye_select_index = rand() & 1;
            if (eye_select_index == 0)
                setup_initial_eyes(&disp1, &disp2);
            else
                setup_angry_eyes(&disp1, &disp2);
            color_scheme_changed = true;
            uart_send_int("M", 100);
        }
    }




























    }

    return 0;


sleep_ms(4);

}

