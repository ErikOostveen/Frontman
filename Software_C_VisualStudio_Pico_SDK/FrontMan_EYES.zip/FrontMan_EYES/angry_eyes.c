#include "angry_eyes.h"
#include <math.h>
#include <stdlib.h>
#include "pico/time.h"

// Color globals (from FrontMan.c)
extern uint16_t COLOR_SCLERA;
extern uint16_t COLOR_PUPIL;

// Display handles
static DisplayPins* d1;
static DisplayPins* d2;

// Appearance
//#define BACKGROUND_COLOR BGR565(20, 20, 20)   // yellow bg
//#define CIRCLE_COLOR     BGR565(255,   0, 0)  // red circles
//#define PUPIL_COLOR      COLOR_BLACK          // black pupils
//#define LID_COLOR        BGR565(45, 23, 14)   // Brown lids

#define BACKGROUND_COLOR BGR565(20, 20, 20)   // static background
// use dynamic colors from FrontMan.c:
#define CIRCLE_COLOR     COLOR_SCLERA
#define PUPIL_COLOR      COLOR_PUPIL
#define LID_COLOR        BGR565(45, 23, 14)   // Brown lids




// Geometry
static const int EYE_CX        = 120;
static const int EYE_CY        = 120;
static const int EYE_RADIUS    = 50;
static const int PUPIL_R       = 20;
static const int PUPIL_BASE_Y  = 125;
static const int PUPIL_BASE_X  = 120;
static const int MAX_OFFSET    = 15;
static const int MAX_V_OFFSET  = 5;
static const int LID_W         = 130;
static const int LID_H         = 25;
static const int LID_CY        = 77;
static const float LID_ANGLE   = 20.0f;
static const int LID_SHIFT     = 30;
static const int LID_LEFT_ADJ  = -20;
static const int LID_RIGHT_ADJ = +15;

// Helper: draw filled circle
static void fill_circle(DisplayPins* disp, int xc, int yc, int r, uint16_t col) {
    for (int dy = -r; dy <= r; dy++) {
        int dx = (int)(sqrtf((float)(r*r - dy*dy)) + 0.5f);
        gc9a01_fast_fill_rect(disp, xc - dx, yc + dy, 2*dx + 1, 1, col);
    }
}

// Helper: draw filled rotated rectangle
static void fill_rotated_rect(DisplayPins* disp, int cx, int cy, int w, int h, float a, uint16_t col) {
    float hw = w * 0.5f, hh = h * 0.5f;
    float rad = a * (M_PI/180.0f), ca = cosf(rad), sa = sinf(rad);
    float lx[4] = {-hw, +hw, +hw, -hw}, ly[4] = {-hh, -hh, +hh, +hh};
    float vx[4], vy[4];
    for (int i = 0; i < 4; i++) {
        vx[i] = lx[i]*ca - ly[i]*sa + cx;
        vy[i] = lx[i]*sa + ly[i]*ca + cy;
    }
    int y0 = (int)floorf(fminf(fminf(vy[0], vy[1]), fminf(vy[2], vy[3])));
    int y1 = (int)ceilf (fmaxf(fmaxf(vy[0], vy[1]), fmaxf(vy[2], vy[3])));
    for (int y = y0; y <= y1; y++) {
        float ys = y + 0.5f, xi[2]; int cnt = 0;
        for (int e = 0; e < 4; e++) {
            int f = (e+1)&3;
            if ((vy[e] <= ys && vy[f] > ys) || (vy[f] <= ys && vy[e] > ys)) {
                float t = (ys - vy[e]) / (vy[f] - vy[e]);
                xi[cnt++] = vx[e] + t*(vx[f] - vx[e]);
            }
        }
        if (cnt < 2) continue;
        if (xi[0] > xi[1]) { float tmp = xi[0]; xi[0] = xi[1]; xi[1] = tmp; }
        int xa = (int)floorf(xi[0]), xb = (int)ceilf(xi[1]);
        gc9a01_fast_fill_rect(disp, xa, y, xb - xa + 1, 1, col);
    }
}

// Draw static parts
static void draw_static(void) {
    gc9a01_fast_fill_rect(d1, 0, 0, 240, 240, BACKGROUND_COLOR);
    gc9a01_fast_fill_rect(d2, 0, 0, 240, 240, BACKGROUND_COLOR);
    fill_circle(d1, EYE_CX, EYE_CY, EYE_RADIUS, CIRCLE_COLOR);
    fill_circle(d2, EYE_CX, EYE_CY, EYE_RADIUS, CIRCLE_COLOR);
    int lc = EYE_CX + LID_SHIFT + LID_LEFT_ADJ;
    int rc = EYE_CX - LID_SHIFT + LID_RIGHT_ADJ;
    fill_rotated_rect(d1, lc, LID_CY, LID_W, LID_H, +LID_ANGLE, LID_COLOR);
    fill_rotated_rect(d2, rc, LID_CY, LID_W, LID_H, -LID_ANGLE, LID_COLOR);
}

// Pupil state
typedef enum { P_FIXATE, P_SMOOTH } PupPhase;
typedef struct {
    int   x_off, y_off;
    int   x_old, y_old;
    int   target_x, target_y;
    float xf, yf, stepx, stepy;
    int   steps, count;
    PupPhase phase;
    absolute_time_t until, next_step;
} PupState;
static PupState ps;

// Random pause
static int rand_period_ms(void) {
    return 500 + rand()%1501;
}

// Clear old pupils
static void clear_old_pupils(void) {
    int sz = 2*PUPIL_R + 1;
    int x1 = PUPIL_BASE_X + ps.x_old - PUPIL_R;
    int y1 = PUPIL_BASE_Y + ps.y_old - PUPIL_R;
    gc9a01_fast_fill_rect(d1, x1, y1, sz, sz, CIRCLE_COLOR);
    gc9a01_fast_fill_rect(d2, x1, y1, sz, sz, CIRCLE_COLOR);
}

// Draw both pupils
static void draw_pupils(void) {
    fill_circle(d1, PUPIL_BASE_X + ps.x_off, PUPIL_BASE_Y + ps.y_off, PUPIL_R, PUPIL_COLOR);
    fill_circle(d2, PUPIL_BASE_X + ps.x_off, PUPIL_BASE_Y + ps.y_off, PUPIL_R, PUPIL_COLOR);
    ps.x_old = ps.x_off;
    ps.y_old = ps.y_off;
}

void setup_angry_eyes(DisplayPins* disp1, DisplayPins* disp2) {
    d1 = disp1; d2 = disp2;
    draw_static();
    // init pupil
    ps.x_off   = MAX_OFFSET;
    ps.y_off   = 0;
    ps.x_old   = ps.x_off;
    ps.y_old   = ps.y_off;
    ps.phase   = P_FIXATE;
    ps.until   = delayed_by_ms(get_absolute_time(), rand_period_ms());
    draw_pupils();
}

void refresh_angry_eyes(void) {
    draw_static();
    draw_pupils();
}

void update_angry_eyes(void) {
    absolute_time_t now = get_absolute_time();
    if (ps.phase == P_FIXATE) {
        if (to_us_since_boot(now) >= to_us_since_boot(ps.until)) {
            // pick new x,y target
            ps.target_x = -MAX_OFFSET + rand()%(2*MAX_OFFSET+1);
            ps.target_y = -MAX_V_OFFSET + rand()%(2*MAX_V_OFFSET+1);
            ps.steps    = 6 + rand()%5;
            ps.count    = 0;
            ps.xf       = ps.x_off;
            ps.yf       = ps.y_off;
            ps.stepx    = (ps.target_x - ps.xf) / ps.steps;
            ps.stepy    = (ps.target_y - ps.yf) / ps.steps;
            ps.next_step= now;
            ps.phase    = P_SMOOTH;
        }
    }
    if (ps.phase == P_SMOOTH) {
        if (to_us_since_boot(now) >= to_us_since_boot(ps.next_step)) {
            clear_old_pupils();
            ps.xf    += ps.stepx;
            ps.yf    += ps.stepy;
            ps.x_off  = (int)(ps.xf + (ps.stepx>0?0.5f:-0.5f));
            ps.y_off  = (int)(ps.yf + (ps.stepy>0?0.5f:-0.5f));
            draw_pupils();
            ps.count++;
            ps.next_step = delayed_by_ms(now, 30);
            if (ps.count >= ps.steps) {
                ps.phase = P_FIXATE;
                ps.until = delayed_by_ms(now, rand_period_ms());
            }
        }
    }
}




