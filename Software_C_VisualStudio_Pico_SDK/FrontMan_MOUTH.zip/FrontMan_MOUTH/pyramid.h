#ifndef PYRAMID_H
#define PYRAMID_H

#include "frontman_gfx.h"
#include "visual_bars.h"    // for BAR_COUNT
#include "ColorSchemes.h"   // for me7_color_schemes and current_color_scheme

// User-adjustable parameters:
extern float pyramidSpinSpeed;       // rotation speed in radians per frame
extern int   pyramidWireThickness;   // thickness of pyramid edges in pixels

// Pyramid scale range and audio normalization constants
#define PYRAMID_MIN_SCALE   0.2f      // scale at zero audio
#define PYRAMID_MAX_SCALE   2.0f      // scale at max audio level
#define AUDIO_MAX_PER_BAND  3000.0f   // expected max per audio band

// Draws a rotating wireframe pyramid spinning upright around its base center,
// size controlled by audio levels, wire colored by first color of current scheme.
void pyramid_show_rotating(DisplayPins* disp, mutex_t* mtx, uint16_t levels[BAR_COUNT]);

#endif // PYRAMID_H