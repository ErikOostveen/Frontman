#ifndef WINAMP_VIZ_3_H
#define WINAMP_VIZ_3_H

#include "gc9a01.h"     // for DisplayPins
#include "pico/mutex.h" // for mutex_t
#include <stdint.h>

/// Renders the “Movement – 6‐way Kaleida” visualization:
///   • disp   = your 240×240 GC9A01 display pins
///   • mtx    = your gfx mutex
///   • levels = 7‐band MSGEQ7 levels (uint16_t[7])
void winamp_viz_3_render(DisplayPins *disp,
                         mutex_t    *mtx,
                         uint16_t    levels[7]);

#endif // WINAMP_VIZ_3_H

