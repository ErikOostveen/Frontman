#ifndef WINAMP_VIZ_7_H
#define WINAMP_VIZ_7_H

#include <stdint.h>
#include "gc9a01.h"       // for DisplayPins, COLOR_BLACK, etc.
#include "pico/mutex.h"
#include "ColorSchemes.h" // for me7_color_schemes[]

/// Render a “Water Bump” ripple effect, plus a pulsating drop-point:
///  • A filled circle at the bottom-right whose radius follows total audio energy.
///  • Six concentric rings expanding outward; expansion speed is driven by audio.
///
///  • disp:   pointer to GC9A01 display pins
///  • mtx:    pointer to gfx_mutex for SPI synchronization
///  • levels: array of 7 band-levels from MSGEQ7
void winamp_viz_7_render(DisplayPins *disp, mutex_t *mtx, uint16_t levels[7]);

#endif  // WINAMP_VIZ_7_H
