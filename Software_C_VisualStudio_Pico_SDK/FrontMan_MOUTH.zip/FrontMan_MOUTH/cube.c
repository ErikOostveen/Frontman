#include "cube.h"
#include <math.h>
#include "ColorSchemes.h"

// Reference color scheme index defined in FrontMan.c
extern volatile int current_color_scheme;

// Default parameter values (only defined once)
float cubeSpinSpeed     = 0.05f;
int   cubeWireThickness = 1;

typedef struct { float x, y, z; } vec3;
typedef struct { int   x, y;     } vec2;

void cube_show_rotating(DisplayPins* disp, mutex_t* mtx, uint16_t levels[BAR_COUNT]) {
    // clear screen
    gfx_fill_screen(disp, BGR565(0,0,0), mtx);

    // compute normalized audio level
    float sum = 0.0f;
    for (int i = 0; i < BAR_COUNT; ++i) sum += levels[i];
    float norm = sum / (1800.0f * BAR_COUNT);
    norm = norm < 0.0f ? 0.0f : (norm > 1.0f ? 1.0f : norm);

    // compute scale
    float cubeScale = CUBE_MIN_SCALE + norm * (CUBE_MAX_SCALE - CUBE_MIN_SCALE);

    // update rotation
    static float angle = 0.0f;
    angle += cubeSpinSpeed;

    // base half-size
    float s = 60.0f * cubeScale;

    // vertices
    vec3 v[8] = {{-s,-s,-s},{s,-s,-s},{s,s,-s},{-s,s,-s},{-s,-s,s},{s,-s,s},{s,s,s},{-s,s,s}};

    // pivot and axis
    vec3 anchor = v[0];
    vec3 axis = {v[6].x-anchor.x, v[6].y-anchor.y, v[6].z-anchor.z};
    float len = sqrtf(axis.x*axis.x + axis.y*axis.y + axis.z*axis.z);
    axis.x /= len; axis.y /= len; axis.z /= len;

    // projection
    const float f = 200.0f, z_offset = 200.0f;

    // wire color from first color of current scheme
    uint16_t wireColor = me7_color_schemes[current_color_scheme].colors[0];

    vec2 p[8];
    for (int i = 0; i < 8; i++) {
        // translate
        float x0=v[i].x-anchor.x, y0=v[i].y-anchor.y, z0=v[i].z-anchor.z;
        // rodrigues
        float ux=axis.x, uy=axis.y, uz=axis.z;
        float dot=ux*x0+uy*y0+uz*z0;
        vec3 cross={uy*z0-uz*y0, uz*x0-ux*z0, ux*y0-uy*x0};
        float c=cosf(angle), si=sinf(angle);
        float x1=ux*dot+(x0-ux*dot)*c+cross.x*si;
        float y1=uy*dot+(y0-uy*dot)*c+cross.y*si;
        float z1=uz*dot+(z0-uz*dot)*c+cross.z*si;
        // translate back and offset Z
        float xt=x1+anchor.x, yt=y1+anchor.y, zt=z1+anchor.z+z_offset;
        // project
        p[i].x=(int)(xt*f/zt)+SCREEN_WIDTH/2;
        p[i].y=(int)(yt*f/zt)+SCREEN_HEIGHT/2;
    }

    // edges
    const int E[12][2]={{0,1},{1,2},{2,3},{3,0},{4,5},{5,6},{6,7},{7,4},{0,4},{1,5},{2,6},{3,7}};
    int half_thick=cubeWireThickness/2;
    for(int e=0;e<12;e++){
        int a=E[e][0], b=E[e][1];
        for(int dx=-half_thick;dx<=half_thick;dx++)for(int dy=-half_thick;dy<=half_thick;dy++){
            gfx_draw_line(disp,p[a].x+dx,p[a].y+dy,p[b].x+dx,p[b].y+dy,wireColor,mtx);
        }
    }
}
