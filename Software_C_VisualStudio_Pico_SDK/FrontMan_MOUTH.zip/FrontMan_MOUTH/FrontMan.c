#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pico/stdlib.h"
#include "hardware/adc.h"
#include "hardware/gpio.h"
#include "hardware/uart.h"
#include "gc9a01.h"
#include "frontman_gfx.h"
#include "pico/mutex.h"
#include "ColorSchemes.h"
#include "visual_bars.h"
#include "visual_bigCircle.h"
#include "cube.h"
#include "pyramid.h"
#include "winamp_viz_1.h"
#include "winamp_viz_2.h"
#include "winamp_viz_3.h"
#include "winamp_viz_4.h"
#include "winamp_viz_5.h"
#include "winamp_viz_6.h"
#include "winamp_viz_7.h"
#include "allColours.h"   
#include "static_image.h"
#include "img_1.h"

#define UART_ID         uart0
#define UART_TX_PIN     16
#define UART_RX_PIN     17
#define UART_BAUDRATE   115200

#define STROBE_PIN      10
#define RESET_PIN       11
#define ADC_PIN         26
#define BAR_COUNT       7
#define SCREEN_WIDTH    240
#define SCREEN_HEIGHT   240

#define SMOOTHING_FACTOR 0.18f
#define GATE_THRESHOLD   115
#define FLOOR_THRESHOLD  200

volatile int current_color_scheme = 0;
volatile int current_visual_index = 0;

// This global is read by allColours_render():
volatile uint16_t latest_all_colours = 0;

static bool has_drawn_static = false;

// ‘prev_half_bars’ is defined in visual_bars.c; declared extern in visual_bars.h

DisplayPins display = { .cs = 5, .dc = 4, .rst = 6 };
mutex_t     gfx_mutex;

static uint16_t smoothed_levels[BAR_COUNT] = {0};
static uint16_t last_levels[BAR_COUNT]     = {0};

//------------------------------------------------------------------------------
// Initialize the MSGEQ7 seven-band audio decoder
//------------------------------------------------------------------------------
void init_msgeq7() {
    gpio_put(RESET_PIN, 0);
    gpio_put(STROBE_PIN, 0);
    sleep_us(100);
    gpio_put(RESET_PIN, 1);
    sleep_us(100);
    gpio_put(RESET_PIN, 0);
    gpio_put(STROBE_PIN, 1);
    sleep_us(100);
}

//------------------------------------------------------------------------------
// Read one frame of MSGEQ7 levels into “levels[ ]” (7 bands) with smoothing & gate
//------------------------------------------------------------------------------
void read_msgeq7(uint16_t levels[BAR_COUNT]) {
    static bool hold[BAR_COUNT] = {false};

    for (int i = 0; i < BAR_COUNT; ++i) {
        gpio_put(STROBE_PIN, 0);
        sleep_us(36);
        adc_select_input(0);

        // Average 4 samples to reduce noise
        uint32_t sum = 0;
        for (int j = 0; j < 4; ++j) {
            sum += adc_read();
            sleep_us(5);
        }
        uint16_t raw = sum / 4;

        uint16_t diff = (raw > last_levels[i])
                            ? (raw - last_levels[i])
                            : (last_levels[i] - raw);

        if (raw < FLOOR_THRESHOLD && diff < GATE_THRESHOLD) {
            hold[i] = true;
        } else if (raw >= FLOOR_THRESHOLD) {
            hold[i] = false;
        }

        if (!hold[i]) {
            last_levels[i] = raw;
            smoothed_levels[i] = (uint16_t)(
                SMOOTHING_FACTOR * smoothed_levels[i] +
                (1.0f - SMOOTHING_FACTOR) * raw
            );
        }

        levels[i] = smoothed_levels[i];

        gpio_put(STROBE_PIN, 1);
        sleep_us(36);
    }

    // Boost band-0 if it’s very low compared to band-1
    if (levels[0] < 0.5f * levels[1]) {
        levels[0] += (uint16_t)(0.1f * levels[1]);
    }
}

//------------------------------------------------------------------------------
// Initialize UART0 for control commands
//------------------------------------------------------------------------------
void init_uart() {
    uart_init(UART_ID, UART_BAUDRATE);
    gpio_set_function(UART_TX_PIN, GPIO_FUNC_UART);
    gpio_set_function(UART_RX_PIN, GPIO_FUNC_UART);
}

//------------------------------------------------------------------------------
// UART input handler
//  – Lines terminate with '\n'.
//  – “C<value>”   → change color scheme (1-based index, convert to 0-based).
//  – “M100”       → next visualization mode (0..11).
//  – “L<decimal>” → set latest_all_colours (decimal) for “All Colours” mode.
//------------------------------------------------------------------------------
void handle_uart_input() {
    static char uart_buf[16];
    static int  uart_buf_index = 0;

    while (uart_is_readable(UART_ID)) {
        char ch = uart_getc(UART_ID);
        if (ch == '\n' || uart_buf_index >= (int)sizeof(uart_buf) - 1) {
            uart_buf[uart_buf_index] = '\0';
            // Examples:
            //   C03     → change to color scheme 3
            //   M100    → advance mode
            //   L53624  → set “All Colours” colour to decimal 53624
            printf("Received UART: %s\n", uart_buf);

            if (uart_buf[0] == 'C') {
                int val = atoi(&uart_buf[1]);
                if (val >= 1 && val <= NUM_ME7_COLOR_SCHEMES) {
                    current_color_scheme = val - 1;
                }
            }

            else if (strcmp(uart_buf, "M100") == 0) {
                // first time only: 0->13; thereafter 1..13->1..13
                if (current_visual_index == 0) {
                    current_visual_index = 1;
                } else {
                    ++current_visual_index;
                    if (current_visual_index > 13)
                        current_visual_index = 1;
                }
            }

            else if (uart_buf[0] == 'L') {
                int decval = atoi(&uart_buf[1]);
                if (decval < 0) decval = 0;
                if (decval > 0xFFFF) decval &= 0xFFFF;
                latest_all_colours = (uint16_t)decval;
            }

            uart_buf_index = 0;
        }
        else {
            uart_buf[uart_buf_index++] = ch;
        }
    }
}

//------------------------------------------------------------------------------
// Main entry-point
//------------------------------------------------------------------------------
int main() {
    stdio_init_all();
    sleep_ms(4);

    // ADC setup for MSGEQ7
    adc_init();
    adc_gpio_init(ADC_PIN);
    adc_select_input(0);

    gpio_init(STROBE_PIN);
    gpio_set_dir(STROBE_PIN, GPIO_OUT);
    gpio_put(STROBE_PIN, 1);

    gpio_init(RESET_PIN);
    gpio_set_dir(RESET_PIN, GPIO_OUT);
    gpio_put(RESET_PIN, 0);

    // Initialize SPI + display, then clear screen
    gc9a01_spi_init();
    gc9a01_init(&display);
    mutex_init(&gfx_mutex);
    gfx_fill_screen(&display, BGR565(0, 0, 0), &gfx_mutex);

    // Initialize prev_half_bars (extern in visual_bars.h)
    for (int i = 0; i < BAR_COUNT; ++i) {
        prev_half_bars[i] = -1;
    }

    init_uart();

    int previous_visual_index = -1;
    while (1) {
        // 1) Handle UART commands (“Cxx”, “M100”, or “L<decimal>”)
        handle_uart_input();

        // 2) If mode changed, clear screen and reset has_drawn_static
        if (current_visual_index != previous_visual_index) {
            gfx_fill_screen(&display, BGR565(0, 0, 0), &gfx_mutex);
            has_drawn_static = false;              // allow a new draw when entering mode 12
            previous_visual_index = current_visual_index;
        }

        // 3) Read MSGEQ7 bands
        uint16_t levels[BAR_COUNT];
        init_msgeq7();
        read_msgeq7(levels);

        // 4) Dispatch to selected visualization (0..10) or “All Colours” (11)
        switch (current_visual_index) {
            case 0:
                if (!has_drawn_static) {
                    static_image_render(&display, &gfx_mutex, levels);
                    has_drawn_static = true;
                }
                break;
            case 1:
                update_bars(levels);
                break;
            case 2:
                draw_big_circle(levels);
                break;
            case 3:
                cube_show_rotating(&display, &gfx_mutex, levels);
                break;
            case 4:
                pyramid_show_rotating(&display, &gfx_mutex, levels);
                break;
            case 5:
                winamp_viz_1_render(&display, &gfx_mutex, levels);
                break;
            case 6:
                winamp_viz_2_render(&display, &gfx_mutex, levels);
                break;
            case 7:
                winamp_viz_3_render(&display, &gfx_mutex, levels);
                break;
            case 8:
                winamp_viz_4_render(&display, &gfx_mutex, levels);
                break;
            case 9:
                winamp_viz_5_render(&display, &gfx_mutex, levels);
                break;
            case 10:
                winamp_viz_6_render(&display, &gfx_mutex, levels);
                break;
            case 11:
                winamp_viz_7_render(&display, &gfx_mutex, levels);
                break;
            case 12:
                allColours_render();
                break;
            case 13:
                if (!has_drawn_static) {
                    img_1_render(&display, &gfx_mutex, levels);
                    has_drawn_static = true;
                }
                break;    
        }

        // 5) Brief delay before next loop
        sleep_ms(50);
    }

    return 0;
}