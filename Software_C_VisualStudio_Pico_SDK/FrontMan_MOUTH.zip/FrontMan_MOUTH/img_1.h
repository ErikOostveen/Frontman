#ifndef IMG_1_H
#define IMG_1_H

#include <stdint.h>
#include "gc9a01.h"         // for DisplayPins
#include "frontman_gfx.h"   // for gfx_fill_rect / SCREEN_WIDTH, SCREEN_HEIGHT
#include "pico/mutex.h"     // for mutex_t

// Dimensions of your actual image:
#define IMG_1_WIDTH   240
#define IMG_1_HEIGHT  240

// We assume img_1_map[IMG_1_WIDTH * IMG_1_HEIGHT] is defined in img_1_map.c:
extern const uint16_t img_1_map[IMG_1_WIDTH * IMG_1_HEIGHT];

// Render function prototype:
void img_1_render(DisplayPins *disp, mutex_t *mtx, uint16_t levels[7]);

#endif // IMG_1_H
