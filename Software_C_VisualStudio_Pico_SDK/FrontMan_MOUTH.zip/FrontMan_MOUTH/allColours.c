#include "allColours.h"
#include "gc9a01.h"
#include <pico/mutex.h>         // For mutex_t, mutex_enter_blocking, mutex_exit
#include "frontman_gfx.h"       // For DisplayPins
#include <stdlib.h>

#define SCREEN_WIDTH   240
#define SCREEN_HEIGHT  240

// These externs link to the definitions in FrontMan.c:
extern DisplayPins         display;
extern mutex_t             gfx_mutex;
extern volatile uint16_t   latest_all_colours;

/// Fill the entire screen with the 16-bit colour in `latest_all_colours`.
void allColours_render(void) {
    uint16_t c = latest_all_colours;

    // Lock the same mutex used by other drawing routines:
    mutex_enter_blocking(&gfx_mutex);
    gc9a01_fast_fill_rect(&display,
                          0, 0,
                          SCREEN_WIDTH, SCREEN_HEIGHT,
                          c);
    mutex_exit(&gfx_mutex);
}

