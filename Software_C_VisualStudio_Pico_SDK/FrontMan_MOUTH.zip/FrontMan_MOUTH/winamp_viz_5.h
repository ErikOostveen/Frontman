// winamp_viz_5.h
#ifndef WINAMP_VIZ_5_H
#define WINAMP_VIZ_5_H

#include <stdint.h>
#include "gc9a01.h"     // for DisplayPins, COLOR_BLACK, etc.
#include "pico/mutex.h" // for mutex_t

/// Render a 3-pixel-thick ring whose radius follows the CENTER audio band (levels[3]).
/// Color is taken from me7_color_schemes[current_color_scheme].colors[0].
///
/// - disp:   pointer to the GC9A01 display pins
/// - mtx:    pointer to the gfx_mutex for SPI synchronization
/// - levels: array of 7 band-levels from MSGEQ7
void winamp_viz_5_init(DisplayPins *disp, mutex_t *mtx);
void winamp_viz_5_render(DisplayPins *disp, mutex_t *mtx, uint16_t levels[7]);

#endif  // WINAMP_VIZ_5_H


