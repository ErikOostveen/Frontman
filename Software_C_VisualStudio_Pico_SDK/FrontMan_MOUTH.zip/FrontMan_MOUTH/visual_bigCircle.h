#ifndef VISUAL_BIGCIRCLE_H
#define VISUAL_BIGCIRCLE_H

#include <stdint.h>

void draw_big_circle(uint16_t levels[7]);

#endif
