#ifndef WINAMP_VIZ_4_H
#define WINAMP_VIZ_4_H

#include "gc9a01.h"
#include "pico/mutex.h" // for mutex_t
#include <stdint.h>

// (We keep an init in case you want to reset the rotation angle at some point.)
// In practice `winamp_viz_4_init()` doesn’t need to be called each frame—just once at startup
// (e.g. if you switch back to this visualization manually).
void winamp_viz_4_init(DisplayPins *disp, mutex_t *mtx);

// levels[0]..levels[6] comes from your MSGEQ7 read.
// This will rotate N radial lines (“spokes”) based on the bass band.
void winamp_viz_4_render(DisplayPins *disp, mutex_t *mtx, uint16_t levels[7]);

#endif // WINAMP_VIZ_4_H

