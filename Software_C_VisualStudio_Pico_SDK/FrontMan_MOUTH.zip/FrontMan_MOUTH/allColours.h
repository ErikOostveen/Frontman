#ifndef ALLCOLOURS_H
#define ALLCOLOURS_H

#include <stdint.h>
#include <stdio.h>
#include "pico/stdlib.h"
#include "pico/time.h"
#include <hardware/pwm.h>
#include <hardware/uart.h>

//
// If FRONTMAN has already defined BGR565, skip re-definition.
//
#ifndef BGR565
/// Pack 8-bit R,G,B into 16-bit BGR565
///   Bits layout:  | b4 b3 b2 b1 b0 | g5 g4 g3 g2 g1 g0 | r4 r3 r2 r1 r0 |
#define BGR565(r, g, b) \
    (uint16_t)( \
        (((b) & 0xF8) << 8) | \
        (((g) & 0xFC) << 3) | \
        (((r) & 0xF8) >> 3) \
    )
#endif  // BGR565

//
// If FRONTMAN already has a function named duty_to_8bit, skip re-definition.
//
#ifndef ALLCOLOURS_DUTY_TO_8BIT
#define ALLCOLOURS_DUTY_TO_8BIT

/// Convert a 0..1000 PWM duty into a 0..255 intensity
static inline uint8_t duty_to_8bit(uint16_t duty) {
    return (uint8_t)((duty * 255) / 1000);
}
#endif  // ALLCOLOURS_DUTY_TO_8BIT

/// Print a 16-bit value over UART0 with a label prefix, e.g. “Rx:0x1234\n”
static inline void allColours_uart_debug(const char *label, uint16_t v) {
    char buf[32];
    int len = snprintf(buf, sizeof(buf), "%s0x%04X\n", label, v);
    uart_write_blocking(uart0, (const uint8_t*)buf, len);
}

/// A small PWM fade structure for one LED channel
typedef struct {
    uint        pin;               // e.g. 11, 12, or 13
    uint        slice_num;         // pwm slice number
    uint32_t    last_toggle_time;  // ms since boot
    uint32_t    fade_time;         // full-ramp period in ms
    bool        fade_in;           // true=ramp up, false=ramp down
    uint16_t    duty;              // 0..1000
} pwm_led_t;

/// Initialize a pwm_led_t on “pin” with a fade period of fade_time_ms
static inline void allColours_init_pwm_led(pwm_led_t *led, uint pin, uint32_t fade_time_ms) {
    led->pin              = pin;
    led->fade_time        = fade_time_ms;
    led->duty             = 0;
    led->fade_in          = true;
    led->last_toggle_time = to_ms_since_boot(get_absolute_time());

    led->slice_num = pwm_gpio_to_slice_num(pin);
    gpio_set_function(pin, GPIO_FUNC_PWM);
    pwm_set_wrap(led->slice_num, 1000);
    pwm_set_clkdiv(led->slice_num, 125);
    pwm_set_enabled(led->slice_num, true);
}

/// Advance one fade step if enough time has passed
static inline void allColours_update_pwm_led(pwm_led_t *led) {
    uint32_t now = to_ms_since_boot(get_absolute_time());
    uint32_t dt  = now - led->last_toggle_time;
    if (dt < (led->fade_time / 1000)) return;
    led->last_toggle_time = now;

    uint16_t step = (uint16_t)((1000 * dt) / led->fade_time);
    if (led->fade_in) {
        if (led->duty + step >= 1000) {
            led->duty    = 1000;
            led->fade_in = false;
        } else {
            led->duty += step;
        }
    } else {
        if (led->duty <= step) {
            led->duty    = 0;
            led->fade_in = true;
        } else {
            led->duty -= step;
        }
    }
    pwm_set_gpio_level(led->pin, led->duty);
}

/// Every tick, FrontMan will call this to draw “all colours”
/// based on the latest UART-received BGR565 value.
void allColours_render(void);

#endif  // ALLCOLOURS_H
