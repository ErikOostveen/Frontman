#ifndef CUBE_H
#define CUBE_H

#include "frontman_gfx.h"
#include "visual_bars.h"    // for BAR_COUNT
#include "ColorSchemes.h"   // for me7_color_schemes and current_color_scheme

// User-adjustable parameters:
extern float cubeSpinSpeed;       // rotation speed in radians per frame
extern int   cubeWireThickness;   // thickness of cube edges in pixels

// Cube size range and audio normalization constants
#define CUBE_MIN_SCALE     0.2f      // scale at zero audio
#define CUBE_MAX_SCALE     2.0f      // scale at max audio level
#define AUDIO_MAX_PER_BAND 3000.0f   // expected max per audio band

// Draws a rotating wireframe cube spinning around one of its vertices,
// with size controlled by audio spectrum levels and wire color taken
// from the first color of the current color scheme.
void cube_show_rotating(DisplayPins* disp, mutex_t* mtx, uint16_t levels[BAR_COUNT]);

#endif // CUBE_H