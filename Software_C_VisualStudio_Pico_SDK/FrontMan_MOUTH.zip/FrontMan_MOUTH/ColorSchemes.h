#ifndef COLOR_SCHEMES_H
#define COLOR_SCHEMES_H

#include "gc9a01.h"

#define NUM_ME7_COLOR_SCHEMES 100
#define BAR_COUNT 7

typedef struct {
    uint16_t colors[BAR_COUNT];
} ME7ColorScheme;

// External declaration only!
extern const ME7ColorScheme me7_color_schemes[NUM_ME7_COLOR_SCHEMES];

#endif

