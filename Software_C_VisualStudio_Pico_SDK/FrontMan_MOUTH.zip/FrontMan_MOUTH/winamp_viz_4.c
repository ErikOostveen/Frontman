// winamp_viz_4.c
#include "winamp_viz_4.h"
#include "frontman_gfx.h"      // for gfx_fill_screen() and gfx_draw_pixel()
#include "ColorSchemes.h"      // for me7_color_schemes[] and current_color_scheme
#include <math.h>              // for cosf(), sinf()

// -------------------------------------------------------------
// Display dimensions and constants
// -------------------------------------------------------------
#define SCREEN_WIDTH    240
#define SCREEN_HEIGHT   240
#define CENTER_X        (SCREEN_WIDTH  / 2)
#define CENTER_Y        (SCREEN_HEIGHT / 2)

// We revert to the original 7 lines (one per MSGEQ7 band)
#define TOTAL_LINES     7
#define NUM_BANDS       7
#define THICKNESS   3 

// Maximum radius so lines never overflow the 240×240 display
#define MAX_RADIUS      (((SCREEN_WIDTH < SCREEN_HEIGHT) ? SCREEN_WIDTH : SCREEN_HEIGHT) / 2)

// -------------------------------------------------------------
// Extern: current_color_scheme is defined in frontman.c
// -------------------------------------------------------------
extern volatile int current_color_scheme;

// -------------------------------------------------------------
// Internal rotation accumulator (in radians)
// -------------------------------------------------------------
static float _rotation = 0.0f;

// -------------------------------------------------------------
// winamp_viz_4_init()
// Just zero out rotation
// -------------------------------------------------------------
void winamp_viz_4_init(DisplayPins *disp, mutex_t *mtx) {
    (void)disp;
    (void)mtx;
    _rotation = 0.0f;
}

// -------------------------------------------------------------
// winamp_viz_4_render()
//   • levels[0..6] from MSGEQ7 (0..4095 each)
//   • We spin the entire wheel by an angle that speeds up with band 0 (bass).
//   • We draw TOTAL_LINES = 7 radial lines, spaced evenly around 360°.
//   • Each line “i” is assigned to band_idx = i. Its length ∝ levels[band_idx].
//   • Its color comes from me7_color_schemes[current_color_scheme].colors[band_idx].
//   • Each line is drawn with a thickness of 2 px by drawing an extra pixel
//     perpendicular to the main line direction.
// -------------------------------------------------------------
void winamp_viz_4_render(DisplayPins *disp, mutex_t *mtx, uint16_t levels[NUM_BANDS]) {
    // 1) Clear the screen to black
    gfx_fill_screen(disp, COLOR_BLACK, mtx);

    // 2) Normalize band 0 (bass) into [0..1], then compute a rotation delta:
    float bass_norm = (float)levels[0] / 2000.0f;
    if (bass_norm < 0.0f) bass_norm = 0.0f;
    if (bass_norm > 1.0f) bass_norm = 1.0f;

    // Idle minimum spin = 0.01 rad/frame; max = 0.30 rad/frame at full bass
    float delta = bass_norm * 0.30f;
    if (delta < 0.01f)      delta = 0.01f;
    if (delta > 0.30f)      delta = 0.30f;
    _rotation += delta;
    if (_rotation > (2.0f * M_PI)) {
        _rotation -= (2.0f * M_PI);
    }

    // 3) Draw TOTAL_LINES radial lines
    //    Each line_i is spaced by (2π / TOTAL_LINES) from the next.
    //    Assign band_idx = i → 0..6
    for (int i = 0; i < TOTAL_LINES; i++) {
        int band_idx = i;  // one line per band

        // a) Compute this line’s angle
        float angle_i = _rotation + ((2.0f * M_PI * i) / (float)TOTAL_LINES);
        float cos_t = cosf(angle_i);
        float sin_t = sinf(angle_i);

        // b) Determine length from levels[band_idx]
        float norm = (float)levels[band_idx] / 4095.0f;
        if (norm < 0.0f) norm = 0.0f;
        if (norm > 1.0f) norm = 1.0f;
        // give every line a minimum 10 px length so it’s always visible;
        // at max band, it can go almost to MAX_RADIUS
        int length = (int)(norm * (MAX_RADIUS - 10)) + 10;
        if (length > MAX_RADIUS) length = MAX_RADIUS;

        // c) Fetch this line’s color from the chosen color‐scheme
        uint16_t line_color = me7_color_schemes[current_color_scheme].colors[band_idx];

        // d) Draw from r = 0..length with thickness = 2 px
        //    We decide perpendicular offset based on whether the line
        //    is more horizontal (|cos_t| > |sin_t|) or more vertical.
        for (int r = 0; r < length; r++) {
            int x = (int)(CENTER_X + cos_t * r);
            int y = (int)(CENTER_Y + sin_t * r);
            if (x < 0 || x >= SCREEN_WIDTH || y < 0 || y >= SCREEN_HEIGHT) {
                break;
            }

            // Draw the “spine” of the line at (x,y):
            gfx_draw_pixel(disp, x, y, line_color, mtx);

            // Now draw (THICKNESS−1) extra pixels perpendicular to (cos_t, sin_t):
            if (fabsf(cos_t) > fabsf(sin_t)) {
                // Line is more horizontal → we expand vertically
                int half = THICKNESS / 2;
                for (int off = -half; off <= half; off++) {
                    if (off == 0) continue;   // we already drew the “center” at off=0
                    int yy = y + off;
                    if (yy >= 0 && yy < SCREEN_HEIGHT) {
                        gfx_draw_pixel(disp, x, yy, line_color, mtx);
                    }
                }
            } else {
                // Line is more vertical → we expand horizontally
                int half = THICKNESS / 2;
                for (int off = -half; off <= half; off++) {
                    if (off == 0) continue;   // already drew the center at off=0
                    int xx = x + off;
                    if (xx >= 0 && xx < SCREEN_WIDTH) {
                        gfx_draw_pixel(disp, xx, y, line_color, mtx);
                    }
                }
            }
        }
    }    
}
