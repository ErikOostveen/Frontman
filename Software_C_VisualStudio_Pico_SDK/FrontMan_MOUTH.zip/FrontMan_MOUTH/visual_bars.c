#include "visual_bars.h"
#include "frontman_gfx.h"
#include "gc9a01.h"
#include "ColorSchemes.h"
#include "pico/mutex.h"

#define SCREEN_WIDTH 240
#define SCREEN_HEIGHT 240
#define CENTER_Y (SCREEN_HEIGHT / 2)
#define MARGIN_Y 2
#define USABLE_WIDTH (SCREEN_WIDTH * 0.8)
#define SPACING 1
#define SILENCE_THRESHOLD 25
#define GAIN 1.5f

extern DisplayPins display;
extern mutex_t gfx_mutex;
extern volatile int current_color_scheme;

int prev_half_bars[BAR_COUNT];

void update_bars(uint16_t levels[BAR_COUNT]) {
    static const int usable_width = (int)USABLE_WIDTH;
    static const int original_bar_width = (usable_width - SPACING * (BAR_COUNT - 1)) / BAR_COUNT;
    static const int bar_width = (int)(original_bar_width * 0.75f);
    static const int used_width = bar_width * BAR_COUNT + SPACING * (BAR_COUNT - 1);
    static const int margin_x = (SCREEN_WIDTH - used_width) / 2;
    static const int available_height = SCREEN_HEIGHT - 2 * MARGIN_Y;
    static const int max_half = (int)((available_height / 2) * 0.8f);

    for (int i = 0; i < BAR_COUNT; ++i) {
        int level = levels[i];
        int effective = level > SILENCE_THRESHOLD ? level - SILENCE_THRESHOLD : 0;
        float gain_adjust = (i == 0) ? 1.4f : 1.0f;
        float scale = ((float)effective / 3000.0f) * GAIN * gain_adjust;
        int half_bar = (int)(scale * max_half);
        if (half_bar > max_half) half_bar = max_half;

        if (half_bar != prev_half_bars[i]) {
            int x = margin_x + i * (bar_width + SPACING);
            int y = CENTER_Y - half_bar;
            int height = half_bar * 2;

            gfx_fill_rect(&display, x, MARGIN_Y, bar_width, available_height, BGR565(0, 0, 0), &gfx_mutex);

            if (half_bar > 0) {
                gfx_fill_rect(&display, x, y, bar_width, height, me7_color_schemes[current_color_scheme].colors[i], &gfx_mutex);
            }

            prev_half_bars[i] = half_bar;
        }
    }
}
