// winamp_viz_5.c
#include "winamp_viz_5.h"
#include "frontman_gfx.h"   // for gfx_fill_screen(), gfx_draw_pixel()
#include "ColorSchemes.h"   // for me7_color_schemes[], current_color_scheme
#include <math.h>           // for cosf(), sinf(), M_PI

// “BASE_RADIUS = 8” as per your JSON spec.
// “CENTER_X/Y = 120” on a 240×240 screen.
#define BASE_RADIUS          2
#define CENTER_X             (SCREEN_WIDTH  / 2)
#define CENTER_Y             (SCREEN_HEIGHT / 2)

// How much to scale center-band into “extra” radius.
// Tweak if you want a larger/smaller expansion.
#define AUDIO_SCALE_FACTOR   0.06f

// Angle step: ~125 points around the full circle.
#define ANGLE_STEP_RAD       0.05f

// Ring thickness (in pixels). Drawing from radius-1..radius+1 → 3px thick.
#define RING_THICKNESS       4

extern volatile int current_color_scheme;  // defined in FrontMan.c

void winamp_viz_5_init(DisplayPins *disp, mutex_t *mtx) {
    // No persistent state needed here.
    (void)disp;
    (void)mtx;
}

void winamp_viz_5_render(DisplayPins *disp, mutex_t *mtx, uint16_t levels[7]) {
    // 1) Clear the entire screen to black each frame
    gfx_fill_screen(disp, COLOR_BLACK, mtx);

    // 2) Read center channel (levels[3])
    uint16_t center_level = levels[3];

    // 3) Map center_level (0…~4095) → extra radius in pixels.
    float extra = center_level * AUDIO_SCALE_FACTOR;
    // Clamp so that total_radius never exceeds screen bounds
    float max_extra = (SCREEN_WIDTH / 2) - BASE_RADIUS - 2;
    if (extra > max_extra) {
        extra = max_extra;
    }

    // 4) Compute total_radius
    float total_radius = BASE_RADIUS + extra;

    // 5) Pick “ring color” from current ME7 color-scheme, index 0.
    //    (You could pick a different band index if desired.)
    uint16_t ring_color = me7_color_schemes[current_color_scheme].colors[0];

    // 6) Loop over angles, draw a 3-pixel-thick outline.
    //    We offset dr = –1..+1 around total_radius to get 3px thickness.
    for (float angle = 0.0f; angle < 2.0f * M_PI; angle += ANGLE_STEP_RAD) {
        float ux = cosf(angle);
        float uy = sinf(angle);

        // Draw three concentric pixels (radius-1, radius, radius+1)
        int half_thick = RING_THICKNESS / 2; // =1
        for (int dr = -half_thick; dr <= half_thick; dr++) {
            float r = total_radius + (float)dr;
            int x = (int)(CENTER_X + ux * r);
            int y = (int)(CENTER_Y + uy * r);
            if (x >= 0 && x < SCREEN_WIDTH && y >= 0 && y < SCREEN_HEIGHT) {
                gfx_draw_pixel(disp, x, y, ring_color, mtx);
            }
        }
    }
}
