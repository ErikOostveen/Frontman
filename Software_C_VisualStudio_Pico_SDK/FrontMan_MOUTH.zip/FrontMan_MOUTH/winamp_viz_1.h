#ifndef WINAMP_VIZ_1_H
#define WINAMP_VIZ_1_H

#include <stdint.h>
#include "gc9a01.h"
#include "ColorSchemes.h"
#include "frontman_gfx.h"
#include "pico/mutex.h"

#define WINAMP_VIZ_PARTICLE_COUNT  64
#define SCREEN_WIDTH   240
#define SCREEN_HEIGHT  240
#define WINAMP_VIZ_CENTER_X  (SCREEN_WIDTH  / 2)
#define WINAMP_VIZ_CENTER_Y  (SCREEN_HEIGHT / 2)

typedef struct {
    float    x, y;
    float    dx, dy;
    int      size;
    int      life;
    uint16_t color;
} Particle;

extern Particle particles[WINAMP_VIZ_PARTICLE_COUNT];

void winamp_viz_1_init(DisplayPins *disp, mutex_t *mtx);
void winamp_viz_1_render(DisplayPins *disp, mutex_t *mtx, uint16_t levels[7]);

#endif // WINAMP_VIZ_1_H
