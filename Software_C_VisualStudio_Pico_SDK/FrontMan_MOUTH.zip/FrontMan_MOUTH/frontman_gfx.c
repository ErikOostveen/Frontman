#include "frontman_gfx.h"
#include <math.h>
#include "pico/sync.h"
#include <stdlib.h>

void gfx_fill_ring(DisplayPins* disp, int cx, int cy, int inner_r, int outer_r, uint16_t color, mutex_t* mtx) {
    mutex_enter_blocking(mtx);
    for (int y = -outer_r; y <= outer_r; y++) {
        int y_sq = y * y;
        int outer_x = (int)sqrtf(outer_r * outer_r - y_sq);
        int inner_x = (y_sq < inner_r * inner_r) ? (int)sqrtf(inner_r * inner_r - y_sq) : 0;

        if (cy + y < 0 || cy + y >= SCREEN_HEIGHT) continue;

        // Draw left arc
        if (cx - outer_x >= 0 && cx - inner_x > cx - outer_x) {
            int span = (cx - inner_x) - (cx - outer_x);
            gc9a01_fast_fill_rect(disp, cx - outer_x, cy + y, span, 1, color);
        }

        // Draw right arc
        if (cx + inner_x <= cx + outer_x && cx + outer_x < SCREEN_WIDTH) {
            int span = (cx + outer_x) - (cx + inner_x) + 1;
            gc9a01_fast_fill_rect(disp, cx + inner_x, cy + y, span, 1, color);
        }
    }
    mutex_exit(mtx);
}


// Fill the whole screen
void gfx_fill_screen(DisplayPins* disp, uint16_t color, mutex_t* mtx) {
    mutex_enter_blocking(mtx);
    gc9a01_fast_fill_rect(disp, 0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, color);
    mutex_exit(mtx);
}

// Filled rectangle
void gfx_fill_rect(DisplayPins* disp, int x, int y, int w, int h, uint16_t color, mutex_t* mtx) {
    mutex_enter_blocking(mtx);
    gc9a01_fast_fill_rect(disp, x, y, w, h, color);
    mutex_exit(mtx);
}

// Rectangle outline
void gfx_draw_rect(DisplayPins* disp, int x, int y, int w, int h, uint16_t color, mutex_t* mtx) {
    mutex_enter_blocking(mtx);
    // Top
    gc9a01_fast_fill_rect(disp, x, y, w, 1, color);
    // Bottom
    gc9a01_fast_fill_rect(disp, x, y + h - 1, w, 1, color);
    // Left
    gc9a01_fast_fill_rect(disp, x, y, 1, h, color);
    // Right
    gc9a01_fast_fill_rect(disp, x + w - 1, y, 1, h, color);
    mutex_exit(mtx);
}

// Filled circle
void gfx_fill_circle(DisplayPins* disp, int x0, int y0, int r, uint16_t color, mutex_t* mtx) {
    mutex_enter_blocking(mtx);
    for (int y = -r; y <= r; y++) {
        int x_span = (int)sqrt(r * r - y * y);
        int x_start = x0 - x_span;
        int x_end   = x0 + x_span;
        if (x_start < 0) x_start = 0;
        if (x_end >= SCREEN_WIDTH) x_end = SCREEN_WIDTH - 1;
        if (y0 + y >= 0 && y0 + y < SCREEN_HEIGHT) {
            gc9a01_fast_fill_rect(disp, x_start, y0 + y, x_end - x_start + 1, 1, color);
        }
    }
    mutex_exit(mtx);
}

// Circle outline (fixed name and prototype)
void gfx_draw_circle(DisplayPins* disp, int x0, int y0, int r, uint16_t color, mutex_t* mtx) {
    int x = 0, y = r;
    int d = 1 - r;
    mutex_enter_blocking(mtx);
    while (y >= x) {
        gc9a01_fast_fill_rect(disp, x0 - x, y0 - y, 2*x + 1, 1, color);
        gc9a01_fast_fill_rect(disp, x0 - y, y0 - x, 2*y + 1, 1, color);
        gc9a01_fast_fill_rect(disp, x0 - x, y0 + y, 2*x + 1, 1, color);
        gc9a01_fast_fill_rect(disp, x0 - y, y0 + x, 2*y + 1, 1, color);
        x++;
        if (d < 0) {
            d += 2*x + 1;
        } else {
            y--;
            d += 2*(x - y) + 1;
        }
    }
    mutex_exit(mtx);
}

// Arc outline (from start_angle to end_angle in degrees, center at x0,y0)
void gfx_draw_arc(DisplayPins* disp, int x0, int y0, int r, int start_angle, int end_angle, uint16_t color, mutex_t* mtx) {
    mutex_enter_blocking(mtx);
    for (int angle = start_angle; angle <= end_angle; angle++) {
        int x = x0 + r * cosf(angle * M_PI / 180);
        int y = y0 + r * sinf(angle * M_PI / 180);
        gc9a01_fast_fill_rect(disp, x, y, 1, 1, color);
    }
    mutex_exit(mtx);
}

// Draw a single pixel
void gfx_draw_pixel(DisplayPins* disp, int x, int y, uint16_t color, mutex_t* mtx) {
    if (x < 0 || y < 0 || x >= SCREEN_WIDTH || y >= SCREEN_HEIGHT) return;
    mutex_enter_blocking(mtx);
    gc9a01_fast_fill_rect(disp, x, y, 1, 1, color);
    mutex_exit(mtx);
}

// Draw a line (Bresenham's algorithm)
void gfx_draw_line(DisplayPins* disp, int x0, int y0, int x1, int y1, uint16_t color, mutex_t* mtx) {
    mutex_enter_blocking(mtx);
    int dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
    int dy = -abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
    int err = dx + dy, e2;
    while (1) {
        gc9a01_fast_fill_rect(disp, x0, y0, 1, 1, color);
        if (x0 == x1 && y0 == y1) break;
        e2 = 2 * err;
        if (e2 >= dy) { err += dy; x0 += sx; }
        if (e2 <= dx) { err += dx; y0 += sy; }
    }
    mutex_exit(mtx);
}

// Outline triangle (connect the points)
void gfx_draw_triangle(DisplayPins* disp, int x0, int y0, int x1, int y1, int x2, int y2, uint16_t color, mutex_t* mtx) {
    gfx_draw_line(disp, x0, y0, x1, y1, color, mtx);
    gfx_draw_line(disp, x1, y1, x2, y2, color, mtx);
    gfx_draw_line(disp, x2, y2, x0, y0, color, mtx);
}

// Filled triangle (scanline fill)
void gfx_fill_triangle(DisplayPins* disp, int x0, int y0, int x1, int y1, int x2, int y2, uint16_t color, mutex_t* mtx) {
    // Sort points by y-coordinate
    if (y0 > y1) { int t; t=x0;x0=x1;x1=t; t=y0;y0=y1;y1=t; }
    if (y1 > y2) { int t; t=x1;x1=x2;x2=t; t=y1;y1=y2;y2=t; }
    if (y0 > y1) { int t; t=x0;x0=x1;x1=t; t=y0;y0=y1;y1=t; }
    mutex_enter_blocking(mtx);

    int total_height = y2 - y0;
    for (int i = 0; i < total_height; i++) {
        bool second_half = i > y1 - y0 || y1 == y0;
        int segment_height = second_half ? y2 - y1 : y1 - y0;
        float alpha = total_height == 0 ? 0.0f : (float)i / total_height;
        float beta  = segment_height == 0 ? 0.0f : (float)(i - (second_half ? y1 - y0 : 0)) / segment_height;
        int ax = x0 + (x2 - x0) * alpha;
        int bx = second_half
            ? x1 + (x2 - x1) * beta
            : x0 + (x1 - x0) * beta;
        if (ax > bx) { int t = ax; ax = bx; bx = t; }
        for (int j = ax; j <= bx; j++) {
            gc9a01_fast_fill_rect(disp, j, y0 + i, 1, 1, color);
        }
    }
    mutex_exit(mtx);
}
