#include "img_1.h"
#include <stdio.h>
#include "pico/mutex.h"
#include "ColorSchemes.h"   // if you need color schemes in here

// Swap R↔B in a 16-bit RGB565 value:
static inline uint16_t rgb565_to_bgr565(uint16_t rgb) {
    uint16_t r = (rgb >> 11) & 0x1F;
    uint16_t g = (rgb >>  5) & 0x3F;
    uint16_t b = (rgb      ) & 0x1F;
    // reassemble as BGR565:
    return (b << 11) | (g << 5) | (r << 0);
}

void img_1_render(DisplayPins *disp, mutex_t *mtx, uint16_t levels[7]) {
    // 1) clear full canvas to black
    gfx_fill_rect(disp,
                  0, 0,
                  SCREEN_WIDTH, SCREEN_HEIGHT,
                  BGR565(0, 0, 0),
                  mtx);

    // 2) center offsets for a 240×240 block
    const int x_offset = (SCREEN_WIDTH  - IMG_1_WIDTH ) / 2;
    const int y_offset = (SCREEN_HEIGHT - IMG_1_HEIGHT) / 2;

    // 3) draw each pixel
    for (int sy = 0; sy < IMG_1_HEIGHT; sy++) {
        for (int sx = 0; sx < IMG_1_WIDTH; sx++) {
            int idx = sy * IMG_1_WIDTH + sx;
            uint16_t rgb = img_1_map[idx];
            uint16_t bgr = rgb565_to_bgr565(rgb);
            gfx_fill_rect(disp,
                          x_offset + sx,
                          y_offset + sy,
                          1, 1,
                          bgr,
                          mtx);
        }
    }
}
