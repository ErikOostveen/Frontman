#include "winamp_viz_7.h"
#include "gc9a01.h"
#include "frontman_gfx.h"
#include "ColorSchemes.h"
#include <math.h>

extern volatile int current_color_scheme;

#define SCREEN_WIDTH   240
#define SCREEN_HEIGHT  240

static const int DROP_X = SCREEN_WIDTH  - 1;
static const int DROP_Y = SCREEN_HEIGHT - 1;
#define NUM_RINGS      6
#define ANGLE_STEP_RAD 0.05f

static float _max_dist   = -1.0f;
static float _time_accum = 0.0f;

static uint32_t _sum_all_bands(const uint16_t levels[7]) {
    uint32_t s = 0;
    for (int i = 0; i < 7; i++) s += levels[i];
    return s;
}

void winamp_viz_7_render(DisplayPins *disp, mutex_t *mtx, uint16_t levels[7]) {
    gfx_fill_screen(disp, COLOR_BLACK, mtx);

    // Compute normalized audio energy (0..1)
    uint32_t energy = _sum_all_bands(levels);
    float audio_norm = (float)energy / (7.0f * 4095.0f);
    if (audio_norm > 1.0f) audio_norm = 1.0f;

    // Draw the bottom-right “drop” circle
    const int DROP_MAX_RADIUS = 20;
    int drop_radius = (int)(audio_norm * DROP_MAX_RADIUS);
    if (drop_radius < 1) drop_radius = 1;
    gfx_fill_circle(disp, DROP_X, DROP_Y, drop_radius,
                    me7_color_schemes[current_color_scheme].colors[0],
                    mtx);

    // Advance time accumulator with strong audio sensitivity
    float speed = 1.0f + (audio_norm * 10.0f);
    _time_accum += speed;

    // First‐time compute of max distance
    if (_max_dist < 0.0f) {
        _max_dist = hypotf((float)DROP_X, (float)DROP_Y);
    }

    float ring_spacing = _max_dist / (float)NUM_RINGS;

    // Draw each of NUM_RINGS concentric rings
    for (int ri = 0; ri < NUM_RINGS; ri++) {
        float raw_r = _time_accum + ri * ring_spacing;
        float r = fmodf(raw_r, _max_dist);
        if (r < 0.0f) r += _max_dist;

        // Replace each single‐pixel point with a small filled circle of radius=1
        for (float theta = 0.0f; theta < (2.0f * M_PI); theta += ANGLE_STEP_RAD) {
            int px = (int)(DROP_X + r * cosf(theta));
            int py = (int)(DROP_Y + r * sinf(theta));

            if (px >= 0 && px < SCREEN_WIDTH && py >= 0 && py < SCREEN_HEIGHT) {
                // <<< change happens here >>>
                gfx_fill_circle(disp, px, py, 2,
                                me7_color_schemes[current_color_scheme].colors[0],
                                mtx);
            }
        }
    }
}

