// static_image.c

#include "static_image.h"
#include <stdio.h>
#include "pico/mutex.h"
#include "ColorSchemes.h"   // if you need color schemes in here

// Swap R↔B in a 16-bit RGB565 value:
static inline uint16_t rgb565_to_bgr565(uint16_t rgb) {
    uint16_t r = (rgb >> 11) & 0x1F;
    uint16_t g = (rgb >>  5) & 0x3F;
    uint16_t b = (rgb      ) & 0x1F;
    // reassemble as BGR565:
    return (b << 11) | (g << 5) | (r << 0);
}

void static_image_render(DisplayPins *disp, mutex_t *mtx, uint16_t levels[7]) {
    // Clear the full 240×240 canvas to black
    gfx_fill_rect(disp,
                  0, 0,
                  SCREEN_WIDTH, SCREEN_HEIGHT,
                  BGR565(0, 0, 0),
                  mtx);

    // Center offsets for 240×240 block (will be 0,0 if your screen is 240×240)
    const int x_offset = (SCREEN_WIDTH  - STATIC_IMAGE_WIDTH)  / 2;
    const int y_offset = (SCREEN_HEIGHT - STATIC_IMAGE_HEIGHT) / 2;

    // Draw each pixel one by one:
    for (int sy = 0; sy < STATIC_IMAGE_HEIGHT; sy++) {
        for (int sx = 0; sx < STATIC_IMAGE_WIDTH; sx++) {
            int idx = sy * STATIC_IMAGE_WIDTH + sx;
            // fetch RGB565 from the map, then swap R↔B for your GC9A01:
            uint16_t rgb = static_image_map[idx];
            uint16_t bgr = rgb565_to_bgr565(rgb);
            gfx_fill_rect(disp,
                          x_offset + sx,
                          y_offset + sy,
                          1, 1,
                          bgr,
                          mtx);
        }
    }
}