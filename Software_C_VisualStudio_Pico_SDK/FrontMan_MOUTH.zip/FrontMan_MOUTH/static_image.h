// static_image.h

#ifndef STATIC_IMAGE_H
#define STATIC_IMAGE_H

#include <stdint.h>
#include "gc9a01.h"         // for DisplayPins
#include "frontman_gfx.h"   // for gfx_fill_rect / SCREEN_WIDTH, SCREEN_HEIGHT
#include "pico/mutex.h"     // for mutex_t

// Dimensions of your actual image:
#define STATIC_IMAGE_WIDTH   240
#define STATIC_IMAGE_HEIGHT  240

// We assume static_image_map[240 * 240] is defined in static_image_map.c:
extern const uint16_t static_image_map[STATIC_IMAGE_WIDTH * STATIC_IMAGE_HEIGHT];

// Render function prototype:
void static_image_render(DisplayPins *disp, mutex_t *mtx, uint16_t levels[7]);

#endif // STATIC_IMAGE_H
