// winamp_viz_3.c
#include "winamp_viz_3.h"
#include "gc9a01.h"         // for BGR565()
#include "frontman_gfx.h"   // for gfx_fill_screen(), gfx_fill_circle()
#include "ColorSchemes.h"   // for me7_color_schemes[], BAR_COUNT
#include <math.h>           // for sinf(), cosf(), M_PI
#include <stdint.h>

// We keep a static “base_angle” that increments every frame.
// At render time we draw a small circle at (radius, angle),
// then mirror it 6× around the center of the 240×240 display.
static float base_angle = 0.0f;

void winamp_viz_3_render(DisplayPins *disp, mutex_t *mtx, uint16_t levels[BAR_COUNT]) {
    // 1) Clear entire frame to black
    gfx_fill_screen(disp, BGR565(0, 0, 0), mtx);

    // 2) Compute average level across all 7 bands
    uint32_t sum = 0;
    for (int i = 0; i < BAR_COUNT; i++) {
        sum += levels[i];
    }
    uint16_t avg_level = (uint16_t)(sum / BAR_COUNT);

    // 3) Find index of the loudest band (0..6)
    int max_band = 0;
    for (int i = 1; i < BAR_COUNT; i++) {
        if (levels[i] > levels[max_band]) {
            max_band = i;
        }
    }

    // 4) Pick that band’s color from the current color scheme
    extern volatile int current_color_scheme;
    uint16_t circle_color = me7_color_schemes[current_color_scheme].colors[max_band];

    // 5) Map average level → radius (0 .. SCREEN_WIDTH/2)
    //    Here we divide by 50 arbitrarily. Tweak “/50” for sensitivity.
    float max_possible = (float)(SCREEN_WIDTH / 2);
    float radius = ((float)avg_level / 25.0f);
    if (radius < 2.0f) {
        radius = 2.0f;
    }
    if (radius > max_possible) {
        radius = max_possible;
    }

    // 6) Increment base_angle so the shape rotates over time.
    //    Tweak the increment (0.05) to adjust spin speed.
    base_angle += 0.05f;
    if (base_angle >= 2.0f * M_PI) {
        base_angle -= 2.0f * M_PI;
    }

    // 7) Draw one small filled circle at (x0, y0) on the “first arm”,
    //    then mirror it 6× around center at 60° intervals.
    const float center = SCREEN_WIDTH / 2.0f; // = 120.0f
    const float angle_step = (2.0f * M_PI) / 6.0f;

    // We choose a fixed small “dot radius” (e.g. 4 pixels)
    int dot_radius = 2 + (avg_level / 200);  // tweak “/200” to taste
    if (dot_radius > 12) dot_radius = 12;    // clamp max size

    for (int k = 0; k < 6; k++) {
        float angle_k = base_angle + (k * angle_step);
        float fx = center + radius * cosf(angle_k);
        float fy = center + radius * sinf(angle_k);

        // Round to integer
        int ix = (int)fx;
        int iy = (int)fy;

        // Only draw if fully inside [0..239]×[0..239]
        if ( (ix - dot_radius) >= 0 &&
             (ix + dot_radius) < SCREEN_WIDTH &&
             (iy - dot_radius) >= 0 &&
             (iy + dot_radius) < SCREEN_HEIGHT )
        {
            gfx_fill_circle(disp, ix, iy, dot_radius, circle_color, mtx);
        }
    }
}

