#include "winamp_viz_1.h"
#include "gc9a01.h"            // for COLOR_BLACK
#include "frontman_gfx.h"      // for gfx_fill_screen(), gfx_fill_circle()
#include "ColorSchemes.h"      // for me7_color_schemes[], current_color_scheme
#include "pico/mutex.h"        // for mutex_t
#include <stdlib.h>            // for rand()
#include <math.h>              // for cosf(), sinf()

// ──── Forward Declarations & Externals ───────────────────────────────────────
// The header already has “extern Particle particles[…]”. Here we simply define it:
Particle particles[WINAMP_VIZ_PARTICLE_COUNT];

// We assume these are defined elsewhere (e.g. in FrontMan.c):
extern DisplayPins    display;
extern mutex_t        gfx_mutex;
extern volatile int   current_color_scheme;

// ──── Initialize ─────────────────────────────────────────────────────────────
// Zero‐out all particles so that none are “alive” at startup.
void winamp_viz_1_init(DisplayPins* disp, mutex_t* mtx) {
    (void)disp;
    (void)mtx;
    for (int i = 0; i < WINAMP_VIZ_PARTICLE_COUNT; i++) {
        particles[i].life = 0;
    }
}

// ──── Spawn Helper ────────────────────────────────────────────────────────────
// Pick a free slot, place a brand‐new particle at the exact center, give it:
//   • velocity based on “level” (we’ll pass in avg_level to match the old white logic),  
//   • size = 6px, life = 40 frames (enough to travel nearly to the 240×240 edges),  
//   • color = me7_color_schemes[current_color_scheme].colors[band_index].
//
// Note: “band_level” is only used here to compute speed. Speed formula is identical to
// the old white‐circle logic, except we clamp between 0.5..3.5 px/frame. If you want
// slightly different sensitivity, you can tweak the divisor or clamps below.
static void spawn_particle_for_band(int band_index, uint16_t band_level) {
    for (int i = 0; i < WINAMP_VIZ_PARTICLE_COUNT; i++) {
        if (particles[i].life <= 0) {
            // a random angle 0..2π:
            float angle = ((float)(rand() % 360)) * (M_PI / 180.0f);

            // START AT EXACT CENTER (240×240 display):
            float cx = (float)WINAMP_VIZ_CENTER_X;
            float cy = (float)WINAMP_VIZ_CENTER_Y;

            // Speed ∝ band_level (we pass avg_level in, so it matches old behavior).
            float speed = ( (float)band_level / 1000.0f );
            if (speed <  0.5f) speed = 0.5f;
            if (speed >  3.5f) speed = 3.5f;

            float vx = speed * cosf(angle);
            float vy = speed * sinf(angle);

            particles[i].x     = cx;
            particles[i].y     = cy;
            particles[i].dx    = vx;
            particles[i].dy    = vy;
            particles[i].size  = 6;    // starting radius
            particles[i].life  = 40;   // frames to live
            // pick its color from the “max_band” index in the active color scheme:
            particles[i].color = me7_color_schemes[current_color_scheme].colors[band_index];
            break;  // only spawn one particle per call
        }
    }
}

// ──── Main Render ─────────────────────────────────────────────────────────────
// Called roughly every 50 ms with a “levels[7]” array. We:
//   1) Clear screen to black.
//   2) Compute avg_level across all 7 bands.
//   3) Determine how many total particles to spawn (exactly as the old white logic did).
//   4) Find the index of the band with the highest level right now (max_band).
//   5) For each spawn, call spawn_particle_for_band(max_band, avg_level).
//   6) Move & shrink each live particle, drawing it in its assigned color.
//
void winamp_viz_1_render(DisplayPins* disp, mutex_t* mtx, uint16_t levels[7]) {
    // 1) Clear to black:
    gfx_fill_screen(disp, COLOR_BLACK, mtx);

    // 2) Compute avg_level across all 7 bands:
    uint32_t sum = 0;
    for (int i = 0; i < 7; i++) {
        sum += levels[i];
    }
    uint16_t avg_level = (uint16_t)(sum / 7);

    // 3) Decide spawn count EXACTLY as before:
    //    For every ~800 units of avg_level, spawn 1 particle, but at most 3.
    int spawns = avg_level / 500;
    if (spawns < 0)    spawns = 0;
    if (spawns > 3)    spawns = 3;

    // 4) Find which band is currently strongest:
    int max_band = 0;
    for (int b = 1; b < 7; b++) {
        if (levels[b] > levels[max_band]) {
            max_band = b;
        }
    }

    // 5) Spawn ‘spawns’ new particles, all attributed to max_band, with speed=avg_level:
    for (int s = 0; s < spawns; s++) {
        spawn_particle_for_band(max_band, avg_level);
    }

    // 6) Move, shrink, and draw every still‐alive particle:
    for (int i = 0; i < WINAMP_VIZ_PARTICLE_COUNT; i++) {
        if (particles[i].life > 0) {
            // Move it:
            particles[i].x += particles[i].dx;
            particles[i].y += particles[i].dy;

            // Start shrinking once life < 20 frames:
            if (particles[i].life < 20 && particles[i].size > 0) {
                particles[i].size--;
            }
            particles[i].life--;

            // Convert to integers:
            int ix = (int)particles[i].x;
            int iy = (int)particles[i].y;
            int r  = particles[i].size;

            // Only draw if fully inside the 240×240 bounds:
            if (r > 0
                && ix - r >= 0
                && ix + r < SCREEN_WIDTH
                && iy - r >= 0
                && iy + r < SCREEN_HEIGHT) {
                gfx_fill_circle(disp, ix, iy, r, particles[i].color, mtx);
            }
        }
    }
}
