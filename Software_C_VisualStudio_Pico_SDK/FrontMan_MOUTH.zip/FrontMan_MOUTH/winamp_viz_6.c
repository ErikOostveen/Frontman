#include "winamp_viz_6.h"
#include "gc9a01.h"         // for COLOR_BLACK, DisplayPins
#include "frontman_gfx.h"   // for gfx_fill_screen() and gfx_draw_pixel()
#include "ColorSchemes.h"   // for me7_color_schemes[][ ]
#include <math.h>

/// We’ll reference the global “current_color_scheme” defined in frontman.c:
extern volatile int current_color_scheme;

#define SCREEN_WIDTH   240
#define SCREEN_HEIGHT  240
#define CENTER_X       (SCREEN_WIDTH  / 2)   // 120
#define CENTER_Y       (SCREEN_HEIGHT / 2)   // 120

/// Number of frames to keep in history on each side of center.
#define HISTORY_LEN    8

/// Raw MSGEQ7 output range ~0…4095 → map to half‐screen (~120px).
#define MAX_LEVEL_F    4095.0f
#define HEIGHT_SCALE   ((float)(SCREEN_HEIGHT / 2) / MAX_LEVEL_F)

/// Each vertical line is 3 pixels wide.
#define LINE_THICKNESS 3

/// Spacing between “logical offsets” so that 3px‐thick lines do not overlap.
/// (We leave 1px gap between them: 3px + 1px = 4px per step.)
#define SPACING        (LINE_THICKNESS + 1)

/// Circular buffer holding the last HISTORY_LEN “center‐band” levels.
static uint16_t history[HISTORY_LEN];

void winamp_viz_6_init(DisplayPins *disp, mutex_t *mtx) {
    (void)disp;
    (void)mtx;
    for (int i = 0; i < HISTORY_LEN; i++) {
        history[i] = 0;
    }
}

void winamp_viz_6_render(DisplayPins *disp, mutex_t *mtx, uint16_t levels[7]) {
    // 1) Clear entire frame to black
    gfx_fill_screen(disp, COLOR_BLACK, mtx);

    // 2) Grab the CENTER band (index 3)
    uint16_t center_level = levels[3];

    // 3) Shift the history array “to the right” (older at higher index)
    for (int i = HISTORY_LEN - 1; i > 0; i--) {
        history[i] = history[i - 1];
    }
    history[0] = center_level;

    // 4) Draw each frame’s line from newest (i=0) to oldest (i=HISTORY_LEN-1).
    for (int i = 0; i < HISTORY_LEN; i++) {
        float lvl    = (float)history[i];
        float half_h = lvl * HEIGHT_SCALE;
        if (half_h > (SCREEN_HEIGHT / 2)) {
            half_h = (SCREEN_HEIGHT / 2);
        }

        // Vertical endpoints, clamped to screen
        int y0 = (int)(CENTER_Y - half_h);
        int y1 = (int)(CENTER_Y + half_h);
        if (y0 < 0)   y0 = 0;
        if (y1 >= SCREEN_HEIGHT) y1 = SCREEN_HEIGHT - 1;

        // Fade factor: i=0 → f=1.0; i=HISTORY_LEN-1 → f = 1.0 - ((HISTORY_LEN-1)/HISTORY_LEN)
        float f = 1.0f - ((float)i / (float)HISTORY_LEN);
        if (f < 0.0f) f = 0.0f;

        // Base color from current color scheme, index 0:
        uint16_t base_color = me7_color_schemes[current_color_scheme].colors[0];

        // Extract BGR565 components and scale by f
        uint8_t r5 = (base_color >> 11) & 0x1F;
        uint8_t g6 = (base_color >> 5)  & 0x3F;
        uint8_t b5 =  base_color        & 0x1F;

        uint8_t r5f = (uint8_t)(r5 * f);
        uint8_t g6f = (uint8_t)(g6 * f);
        uint8_t b5f = (uint8_t)(b5 * f);

        uint16_t draw_color = (uint16_t)((r5f << 11) | (g6f << 5) | b5f);

        // Compute horizontal offset for this “history index”:
        //   i = 0 → offset = 0  (draw centered)
        //   i = 1 → offset = ±SPACING
        //   i = 2 → offset = ±2*SPACING, etc.
        int base_offset = i * SPACING;

        // For each “side” (i=0 only center, i>=1 both ±):
        if (i == 0) {
            // Single 3px‐wide line centered at CENTER_X
            for (int dx = -(LINE_THICKNESS/2); dx <= +(LINE_THICKNESS/2); dx++) {
                int x = CENTER_X + dx;
                if (x < 0 || x >= SCREEN_WIDTH) continue;
                for (int y = y0; y <= y1; y++) {
                    gfx_draw_pixel(disp, x, y, draw_color, mtx);
                }
            }
        } else {
            // Draw on both left and right sides at CENTER_X ± base_offset
            for (int sign = -1; sign <= 1; sign += 2) {
                int x_center = CENTER_X + sign * base_offset;
                // For each pixel‐column of thickness, shift by ±1
                for (int dx = -(LINE_THICKNESS/2); dx <= +(LINE_THICKNESS/2); dx++) {
                    int x = x_center + dx;
                    if (x < 0 || x >= SCREEN_WIDTH) continue;
                    for (int y = y0; y <= y1; y++) {
                        gfx_draw_pixel(disp, x, y, draw_color, mtx);
                    }
                }
            }
        }
    }
}
