#ifndef WINAMP_VIZ_2_H
#define WINAMP_VIZ_2_H

#include "gc9a01.h"        // for DisplayPins
#include "pico/mutex.h"    // for mutex_t
#include <stdint.h>

/// Renders the “Unique Tone – Additive blend” visualization.
///   • disp  = pointer to your 240×240 GC9A01 display pins
///   • mtx   = pointer to your gfx_mutex
///   • levels[7] = the 7‐band audio levels from MSGEQ7
void winamp_viz_2_render(DisplayPins *disp,
                         mutex_t    *mtx,
                         uint16_t    levels[7]);

#endif // WINAMP_VIZ_2_H

