#ifndef WINAMP_VIZ_6_H
#define WINAMP_VIZ_6_H

#include <stdint.h>
#include "gc9a01.h"    // for DisplayPins, COLOR_BLACK, etc.
#include "pico/mutex.h"

/// Initialize any internal state (here, just zeroing the history).
void winamp_viz_6_init(DisplayPins *disp, mutex_t *mtx);

/// Render a 5‐frame “oscilloscope lines” effect:
/// • New vertical line at CENTER_X whose height is levels[3].
/// • Previous 4 frames’ lines shift left/right by ±1…±4 pixels (fading toward black).
/// • Beyond ±5 pixels is fully black (i.e. removed).
///
/// - disp:   pointer to the GC9A01 display pins
/// - mtx:    pointer to the gfx_mutex for SPI synchronization
/// - levels: 7‐element array of MSGEQ7 band‐levels
void winamp_viz_6_render(DisplayPins *disp, mutex_t *mtx, uint16_t levels[7]);

#endif  // WINAMP_VIZ_6_H
