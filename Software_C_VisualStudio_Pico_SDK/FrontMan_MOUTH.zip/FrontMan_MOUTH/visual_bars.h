#ifndef VISUAL_BARS_H
#define VISUAL_BARS_H

#include <stdint.h>

#define BAR_COUNT 7
extern int prev_half_bars[BAR_COUNT];

void update_bars(uint16_t levels[BAR_COUNT]);

#endif // VISUAL_BARS_H
