#include "visual_bigCircle.h"
#include "gc9a01.h"
#include "frontman_gfx.h"
#include "ColorSchemes.h"
#include "pico/mutex.h"
#include <math.h>

extern DisplayPins display;
extern mutex_t gfx_mutex;
extern volatile int current_color_scheme;

static uint8_t scale_channel(uint8_t base, float t) {
    int result = (int)(t * base);
    if (result > 255) result = 255;
    return (uint8_t)result;
}

static uint16_t scale_color(uint16_t color, float brightness) {
    uint8_t r = ((color >> 11) & 0x1F) << 3;
    uint8_t g = ((color >> 5) & 0x3F) << 2;
    uint8_t b = (color & 0x1F) << 3;

    float t = powf(brightness, 0.65f);

    r = scale_channel(r, t);
    g = scale_channel(g, t);
    b = scale_channel(b, t);

    return BGR565(r, g, b);
}

void draw_big_circle(uint16_t levels[7]) {
    const ME7ColorScheme *scheme = &me7_color_schemes[current_color_scheme];

    float brightness[7];
    for (int i = 0; i < 7; ++i) {
        brightness[i] = (float)levels[i] / 1024.0f;
        if (brightness[i] > 1.0f) brightness[i] = 1.0f;
    }

    const int cx = 120;
    const int cy = 120;
    const int max_radius = 105;
    const int spacing = max_radius / 7;
    const int gap = 0; // increate to create gaps between the rings

    for (int i = 6; i >= 0; --i) {
        uint16_t color = scale_color(scheme->colors[i], brightness[i]);
        int outer_r = (i + 1) * spacing;
        int inner_r = outer_r - spacing + gap;
        if (inner_r < 0) inner_r = 0;
        gfx_fill_ring(&display, cx, cy, inner_r, outer_r, color, &gfx_mutex);
    }
}



