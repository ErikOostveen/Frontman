// winamp_viz_2.c
#include "winamp_viz_2.h"
#include "gc9a01.h"         // for BGR565(), COLOR_BLACK
#include "frontman_gfx.h"   // for gfx_fill_screen(), gfx_fill_circle()
#include "ColorSchemes.h"   // for me7_color_schemes[], NUM_ME7_COLOR_SCHEMES, BAR_COUNT
#include <stdint.h>

// -----------------------------------------------------------------------------
// “Unique Tone – Additive blend”
//   JSON snippet:
//
//     {
//       "name":"Unique Tone - Additive blend",
//       "clearFrame":true,
//       "components":[{
//         "type":"UniqueTone",
//         "group":"Trans",
//         "enabled":true,
//         "color":"#ffffff",
//         "blendMode":"ADDITIVE",
//         "invert":false
//       }]
//     }
//
//   We interpret it as:
//     1) clear each frame to black
//     2) find the band with the highest level (0..6) 
//        ⇒ pick that band’s color from the current ME7 color scheme
//     3) draw a single filled circle at (120,120) whose radius ∝ the average level
//     4) simulate “additive” blending simply by drawing that solid circle in the chosen color
// -----------------------------------------------------------------------------
//
// Assumptions:
//   • current_color_scheme (0..NUM_ME7_COLOR_SCHEMES‒1) is a global volatile int
//   • DisplayPins display; mutex_t gfx_mutex; are defined/initialized in frontman.c
//   • SCREEN_WIDTH = SCREEN_HEIGHT = 240
//

void winamp_viz_2_render(DisplayPins *disp, mutex_t *mtx, uint16_t levels[BAR_COUNT]) {
    // 1) Clear screen to black
    gfx_fill_screen(disp, BGR565(0, 0, 0), mtx);

    // 2) Compute average level across all 7 MSGEQ7 bands
    uint32_t sum = 0;
    for (int i = 0; i < BAR_COUNT; i++) {
        sum += levels[i];
    }
    uint16_t avg_level = (uint16_t)(sum / BAR_COUNT);

    // 3) Find the index of the loudest band (0..6)
    int max_band = 0;
    for (int i = 1; i < BAR_COUNT; i++) {
        if (levels[i] > levels[max_band]) {
            max_band = i;
        }
    }

    // 4) Pick that band’s color from the currently selected ME7 scheme
    //    (current_color_scheme is a volatile int defined in frontman.c)
    extern volatile int current_color_scheme;
    uint16_t color = me7_color_schemes[current_color_scheme].colors[max_band];

    // 5) Map average level → circle radius. Tweak “/50” to adjust sensitivity.
    int radius = (int)(avg_level / 12);
    if (radius < 1) {
        radius = 1;
    }
    if (radius > (SCREEN_WIDTH / 2)) {
        radius = SCREEN_WIDTH / 2;
    }

    // 6) Draw one filled circle at the center (120,120)
    gfx_fill_circle(disp,
                    SCREEN_WIDTH  / 2,
                    SCREEN_HEIGHT / 2,
                    radius,
                    color,
                    mtx);
}

